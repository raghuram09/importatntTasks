import UIKit

class car{
    
    var myOwner:person?
    func usecar(){
        
        print("using a car")
        
    }
    
    deinit{
        print("clearing the car memory")
        
    }
}

class person{
    
    var mycar:car?
    
    func drive(){
        
        print(" driving a car")

    }
    
    deinit{
        
        print("crearing the person memory")

    }
}

var acar:car? = car() //reatin count 1

weak var bcar = acar //reatin count 2 when we are using the weak retain count decress 2 to 1 and also weak does not incress the memory reference count


acar = nil

acar?.usecar()
//acar?.usecar()

//acar = nil
