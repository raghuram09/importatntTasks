//
//  ContentView.swift
//  ApiMVVM
//
//  Created by Raghu on 28/02/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        RouterView {
            LoginView()
        }
    }
}

#Preview {
    ContentView()
}
