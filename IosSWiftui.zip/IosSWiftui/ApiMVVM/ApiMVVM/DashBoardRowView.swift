//
//  DashBoardRowView.swift
//  ApiMVVM
//
//  Created by Raghu on 28/02/24.
//

import SwiftUI

struct DashBoardRowView: View {
    
    let eachProduct:Product
    
    var body: some View {

            
            HStack(spacing: 15){
                
                VStack{
                    Spacer()
                    
                    Text("Title: \(eachProduct.title)")
                        .lineLimit(1)
                        .font(.system(size: 15))
                    
                    HStack{
                        Spacer()
                        
                        Text("ID: \(eachProduct.id)")
                            .font(.system(size: 15))
                        
                        Spacer()
                        
                        Text("category: \(eachProduct.category)")
                            .lineLimit(1)
                        
                        Spacer()
                    }
                    
                    Spacer()
                    
                }
                
                Button {
                    
                    
                    
                } label: {
                    Image(systemName: "trash")
                    
                }
                .padding(.trailing)
                
            }

        }
        
        
    }

//#Preview {
//    DashBoardRowView(eachProduct: Product)
//}
