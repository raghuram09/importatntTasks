//
//  DashBoardView.swift
//  ApiMVVM
//
//  Created by Raghu on 24/02/24.
//

import SwiftUI

protocol viewControllerDelegate {
    
    mutating func successResponce(responce:[Product])
    func failureResponce(error: networkError?)
    
}
extension viewControllerDelegate{
    
    func failureResponce(error: networkError?){
        
        //default implementation && common implentation
        
        print(error?.localizedDescription ?? "")
    }
}

struct DashBoardView: View {
    
    @EnvironmentObject var router: Router

   @ObservedObject var viewModel = ProductViewModel()

    @State private var path = [String]()
    @State var search:String = ""
    
    @State private var filteredProducts:[Product] = []
    
    private var finalproducts:[Product]{
        
        filteredProducts.isEmpty ?viewModel.products : filteredProducts
    }

    
    var body: some View {
            VStack{
                
                List{
                    ForEach(finalproducts) { productObject in
                        DashBoardRowView(eachProduct: productObject)
                        
                            .onTapGesture {
                                
                                router.navigateTo(.viewB)
                            }

                        
                    }
                }
                
            }
        
            
            .searchable(text: $search )
            .onChange(of: search) {
                performSearch(keyword: search)
            }
            
            .task {
            await viewModel.getProductsData()
            
        }
    }
    
    private func performSearch(keyword:String){
        
        filteredProducts = viewModel.products.filter { product in
            
            product.title.contains(keyword)
            
        }
    }
        
}

#Preview {
    DashBoardView()
}

//extension DashBoardView:viewControllerDelegate{
//    mutating func successResponce(responce: [Product]) {
//        
//        
//        products = responce
//        
//        print(products)
//
//        
//    }
//    
//    func failureResponce(error: networkError?) {
//        
//        
//    }
//    
//    
//    
//}
