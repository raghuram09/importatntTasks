//
//  Extension.swift
//  ApiMVVM
//
//  Created by Raghu on 24/02/24.
//

import Foundation
extension URL{
    
    static func productURL() ->URL?{

        return URL(string: "https://fakestoreapi.com/products")
        
    }
    
}
