//
//  ContentView.swift
//  ApiMVVM
//
//  Created by Raghu on 24/02/24.
//

import SwiftUI

    
struct LoginView: View {
    var viewModel = ProductViewModel()
    var products : [Product] = []
    @ObservedObject var LovinviewModel = LoginViewModel()
    @State var showAlert:Bool = false
    @State private var path = [String]()
    
    @EnvironmentObject var router: Router

    var body: some View {
//        NavigationStack(path: $path){
            
            ZStack {
                Image("sky")
                    .resizable()
                    .ignoresSafeArea()
                
                
                VStack(alignment: .leading, spacing: 20) {
                    Spacer()
                    Text("Log in")
                        .foregroundColor(.white)
                        .font(.system(size: 40, weight: .medium, design: .rounded))
                        .underline()
                    
                    TextField("Username", text: $LovinviewModel.email)
                        .textFieldStyle(.roundedBorder)
                        .textInputAutocapitalization(.never)
                    SecureField("Password", text: $LovinviewModel.password)
                        .textFieldStyle(.roundedBorder)
                        .textInputAutocapitalization(.never)
                        .privacySensitive()
                    
                    
                    HStack(spacing: 5) {
                        
                        Button(action: {
                            
                            LovinviewModel.checkValidations { status in
                                
                                if status == true{
                                    print("login sucess")
                                  
//                                    path.append("DashBoard")
                                    router.navigateTo(.viewA)
                                    
                                }else{
                                    showAlert = true
                                }
                            }
                            
                        }, label: {
                            
                            Spacer()
                            
                            Text("Login")
                                .fontWeight(.heavy)
                                .font(.title3)
                                .frame(width: 100, height: 30, alignment: .center)
                                .padding()
                                .background(LinearGradient(gradient: Gradient(colors: [.pink,.purple]), startPoint: .leading, endPoint: .trailing))
                                .cornerRadius(30)
                            
                            Spacer()
                            
                        })
                        Button(action: {
                            
                            
//                            path.append("Register")
                            
                        }, label: {
                            
                            Spacer()
                            
                            Text("Register")
                                .fontWeight(.heavy)
                                .font(.title3)
                                .frame(width: 100, height: 30, alignment: .center)
                                .padding()
                                .background(LinearGradient(gradient: Gradient(colors: [.pink,.purple]), startPoint: .leading, endPoint: .trailing))
                                .cornerRadius(30)
                            
                            Spacer()
                            
                        })
                        
                    }
                    
                    
                    VStack(spacing: 20){
                        
                        Button(action: {
                            
                            
                        }, label: {
                            Spacer()
                            Text("Login With FaceBook")
                                .frame(height: 40, alignment: .center)
                                .background(LinearGradient(gradient: Gradient(colors: [.blue,.white]), startPoint: .leading, endPoint: .trailing))
                                .cornerRadius(10)
                                .tint(.white)
                            Spacer()
                        })
                        
                        
                        Button(action: {
                            
                            
                            
                        }, label: {
                            Spacer()
                            Text("Login With Gmail")
                                .frame(height: 40, alignment: .center)
                                .background(LinearGradient(gradient: Gradient(colors: [.red,.purple]), startPoint: .leading, endPoint: .trailing))
                                .cornerRadius(10)
                                .tint(.white)
                            Spacer()
                            
                            
                        })
                        
                    }
                    
                    
                    Spacer()
                }
                
                
                .padding(.leading, 15)
                .padding(.trailing, 15)
                
                if showAlert {
                    
                    CustomDialog(isActive: $showAlert, title: "MyApp", message: "Plese enter valid Credentials", buttonTitle: "Next", action: {
                        
                    })
                }
        
//            .navigationDestination(for: String.self, destination: { selection in
//                
//                if selection == "DashBoard" {
//                    
//                    DashBoardView()
//                }
//                else if selection == "Register"{
//                    
//                    ProductsGridView()
//                    
//                }
//            })
//            .navigationBarBackButtonHidden()
        }
   
    
                .frame(width: UIScreen.main.bounds.width)
                .padding()
                .ignoresSafeArea()

                .transition(.offset(x: 0, y: 850))
            
//            .task {
//            viewModel.vcDelegate = self
//            
//            await viewModel.getProductsData()
//            
//        }
        
        
    }
}

#Preview {
    LoginView()
}

//extension LoginView: viewControllerDelegate{
//    
//    mutating func successResponce(responce: [Product]) {
//        
//        print("successResponce  \(responce)")
//        self.products = responce
//        
//    }
//    
//    
//    func failureResponce(error: networkError?) {
//        
//        print("failureResponce  \(String(describing: error))")
//        
//    }
//}
