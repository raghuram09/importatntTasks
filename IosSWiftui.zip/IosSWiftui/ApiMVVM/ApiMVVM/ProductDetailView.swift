//
//  ProductDetailView.swift
//  ApiMVVM
//
//  Created by Raghu on 28/02/24.
//

import SwiftUI

struct ProductDetailView: View {
    
    @EnvironmentObject var router: Router

    var body: some View {
        
        VStack{
            
            Button {
                router.popbasedOnIndex(index: 2)
                    
            } label: {
                
                Text("BackButton")
            }

        }
    }
}

#Preview {
    ProductDetailView()
}
