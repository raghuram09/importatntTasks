//
//  ProductsGridView.swift
//  ApiMVVM
//
//  Created by Raghu on 28/02/24.
//

import SwiftUI

struct ProductsGridView: View {
    var colums = Array(repeating: GridItem(.flexible(),spacing: 15), count: 2)
    
    @ObservedObject var viewModel = ProductViewModel()
    var body: some View {
       
        VStack{
            //GridView
            
            ScrollView(.vertical, showsIndicators:false){
                
                HStack{
                    
                    Text("Travel")
                        .font(.system(size: 35 ,weight: .bold))
                        .foregroundColor(.black)
                    Spacer()
                    
                    Button {
                        
                    } label: {
                        
                        Image("menu")
                            .resizable()
                            .frame(width: 30,height: 30)
                    }

                }
                
                .padding([.horizontal,.top  ])
                
                //GridView
                LazyVGrid(columns: colums, spacing: 25){
                    
                    ForEach(viewModel.products){ eachProduct in
                        
                        VStack(alignment: .leading, spacing: 10){
                            
                            
                            Text("\(eachProduct.id)")
                                .font(.system(size: 40))
                                .fontWeight(.bold)
                            
                        }
                        
                    }
                }
                .padding(.horizontal)
            }
            
            .padding(.top,UIApplication.shared.windows.first?.safeAreaInsets.top)

        }
        .background(Color.white.edgesIgnoringSafeArea(.all))
        
        .task {
        await viewModel.getProductsData()
        
    }
      
    }
}

#Preview {
    ProductsGridView()
}
