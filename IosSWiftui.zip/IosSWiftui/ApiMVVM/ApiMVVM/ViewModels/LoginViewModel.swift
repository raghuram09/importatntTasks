//
//  LoginViewModel.swift
//  ApiMVVM
//
//  Created by Raghu on 27/02/24.
//

import Foundation
import SwiftUI

class LoginViewModel:ObservableObject{
    
    @Published var email = "raghu@gmail.com"
    @Published var password = "Reddy@123$"

    func checkValidations(completion:(Bool) -> Void){
        
        if email.isValidEmail && password.count > 5 && password.count <= 15 && password.isvalidPassword{
            
            completion(true)
            
        }else{
            
            completion(false)
        }
        
    }
    
    
    func checkValidationsTest(){
        
        if email.isValidEmail && password.count > 5 && password.count <= 15 && password.isvalidPassword{
            
  
            
        }else{
            
   
        }
        
    }
}
