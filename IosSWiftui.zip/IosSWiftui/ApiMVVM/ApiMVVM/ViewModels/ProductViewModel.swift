//
//  ProductViewModel.swift
//  ApiMVVM
//
//  Created by Raghu on 24/02/24.
//

import Foundation
 class ProductViewModel:ObservableObject{
    
    @Published var products: [Product] = []

    
    
//    var vcDelegate:viewControllerDelegate?
//
//    
//    func getProductsData() async{
//        
//        ApiService.shared.getProductsData { responce  in
//            
//            
//            switch responce{
//                
//            case .success(let products):
//                
//                print(products)
//                self.vcDelegate?.successResponce(responce: products)
//                
//            case.failure(let error ):
//                
//                print(error)
//                self.vcDelegate?.failureResponce(error: .message(error))
//            }
//        }
//        
//    }
    
    
        func getProductsData() async{
    
            ApiService.shared.getProductsData { responce  in
    
    
                switch responce{
    
                case .success(let productsList):
    
                    DispatchQueue.main.sync {
                        self.products = productsList
                    }
                    //  print(self.products)

    
                case.failure(let error ):
    
                    print(error)
                    
                }
            }
    
        }
    
}
