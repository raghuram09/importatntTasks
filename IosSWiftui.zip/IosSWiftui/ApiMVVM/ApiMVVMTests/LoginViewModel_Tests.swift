//
//  LoginViewModel_Tests.swift
//  ApiMVVMTests
//
//  Created by Raghu on 27/02/24.
//

import XCTest
@testable import ApiMVVM
final class LoginViewModel_Tests: XCTestCase {
    
    //Naming Structure : test_Viewmodel_Functiontest_expectation
    
    //Testing Structure : Given , when , then
    var  loginStatus:Bool = true

    var loginViewModel = LoginViewModel()
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        loginViewModel = LoginViewModel()
   
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func test_LoginViewModel_checkValidations_istrue(){
        
        let mail = "raghu@gmail.com"
        
        loginViewModel.email = mail
        
        XCTAssertTrue(loginViewModel.email.isValidEmail)
        
        
    }
    
    
}
