//
//  ProductModel.swift
//  ApiMVVM
//
//  Created by Raghu on 24/02/24.
//

import Foundation

struct Product: Codable,Identifiable{
    
    let id: Int
    let title: String
    let price:Float
    let description:String
    let category:String
    let image:String
    let rating:Rate
    
}

struct Rate:Codable{
    
    let rate:Float
    let count:Int
}

struct userProduct{
    
    let id: Int
    let title: String
    let price:Float
   
    
}

