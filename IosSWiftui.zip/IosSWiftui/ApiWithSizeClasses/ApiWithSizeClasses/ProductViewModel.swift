//
//  ProductViewModel.swift
//  ApiMVVM
//
//  Created by Raghu on 24/02/24.
//

import Foundation



 class ProductViewModel{
    
   var products: [Product] = []
    
   // var vcDelegate:viewControllerDelegate?
    
//    func getProductsData() {
//        
//        ApiService.shared.getProductsData { responce  in
//            
//            
//            switch responce{
//                
//            case .success(let products):
//                
//                self.vcDelegate?.successResponce(responce: products)
//                
//            case.failure(let error ):
//                
//                print(error)
//                self.vcDelegate?.failureResponce(error: .message(error))
//            }
//        }
//        
//    }
//     
//     
     
     
     
     func getProductsList(completion:@escaping(Result<[Product],networkError>) ->Void) {
         
         ApiService.shared.getProductsData { responce  in
             
             
             switch responce{
                 
             case .success(let products):
                 
                 completion(.success(products))
                 
             case.failure(let error ):
                 
                 print(error)

                 completion(.failure(.noData))
             }
         }
         
     }
    
    
//        func getProductsData() {
//    
//            ApiService.shared.getProductsData { responce  in
//    
//    
//                switch responce{
//    
//                case .success(let productsList):
//    
//                    DispatchQueue.main.sync {
//                        self.products = productsList
//                    }
//                    //  print(self.products)
//
//    
//                case.failure(let error ):
//    
//                    print(error)
//                    
//                }
//            }
//    
//        }
    
}
