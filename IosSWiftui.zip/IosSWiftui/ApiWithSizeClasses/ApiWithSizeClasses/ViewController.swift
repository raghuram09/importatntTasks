//
//  ViewController.swift
//  ApiWithSizeClasses
//
//  Created by Raghu on 28/02/24.
//

import UIKit


protocol viewControllerDelegate {
    
    mutating func successResponce(responce:[Product])
    func failureResponce(error: networkError?)
    
}
extension viewControllerDelegate{
    
    func failureResponce(error: networkError?){
        
        //default implementation && common implentation
        
        print(error?.localizedDescription ?? "")
    }
}
class ViewController: UIViewController {
 
    var viewModel = ProductViewModel()
    
    var ListProducts : [Product] = []

    @IBOutlet weak var DataTable: UITableView!
    override func viewDidLoad()  {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        getproductsData()
        
        
    }
    
    

    func getproductsData() {
        viewModel.getProductsList { result in
            switch result{
            case .success(let products):
                
               // print(products)
                self.ListProducts = products
             
                print(self.ListProducts)
                DispatchQueue.main.sync {
                    self.DataTable.reloadData()
                }
            case.failure(let error):
                
                print(error)
              
            }
            
            
        }
        
    }
    
}

//extension ViewController: viewControllerDelegate{
//    func successResponce(responce: [Product]) {
//        
//        
//        datagetting(data: responce)
//        
//    }
//}

extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return ListProducts.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TVCell") as! TVCell

        let loadData = ListProducts[indexPath.row]
        
        cell.nameTxt.text = loadData.title
        
        return cell
    }
    
    
    
}
