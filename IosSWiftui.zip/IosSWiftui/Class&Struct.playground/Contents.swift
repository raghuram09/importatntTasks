import UIKit


class Software{
    
    var language:String!
    var version:String!
    
    init(language: String!, version: String!) {
        self.language = language
        self.version = version
    }
    
}

var s1 = Software(language: "Swift", version: "5")

var s2 = s1

print(s2.language!)

s2.language = "React"

print(s2.language!)
print(s1.language!)



//struct not support inheritance but we can achive using protocol

protocol role{
    
    func userUpdate(username:String)
    
}

extension role{
    
    func userUpdate(username:String){
        
        
        print(username)
    }
    
}
struct person:role{

    var name:String!
    var age:Int!
    
    var classRef  = Software(language: "java", version: "2.0")
    
}

var p1 = person()

p1.classRef.language = "android"
p1.name = "raghu"
p1.userUpdate(username: "sandhya")


var p2 = p1

print(p1.name!)

p2.name = "Sara"
p2.age = 29
p2.classRef.language = "Sql"

print(p2.name!)
print(p2.age!)
print(p2.classRef.language!)

print(p1.classRef.language ?? "")
print(p1.name!)


