//
//  CombineImageCacheApp.swift
//  CombineImageCache
//
//  Created by Raghu on 13/03/24.
//

import SwiftUI

@main
struct CombineImageCacheApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
