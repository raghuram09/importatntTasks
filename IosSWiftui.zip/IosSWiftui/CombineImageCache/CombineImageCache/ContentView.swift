//
//  ContentView.swift
//  CombineImageCache
//
//  Created by Raghu on 13/03/24.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var VM = ProductViewModel()
    var body: some View {
        VStack {
           
            List{
                
                ForEach(VM.productsArray) { rowdata in
                    
                    RowView(rowData: rowdata)
                }
            }
        }

        
    }
}

#Preview {
    ContentView()
}
