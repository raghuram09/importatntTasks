//
//  DownloadImageView.swift
//  CombineImageCache
//
//  Created by Raghu on 14/03/24.
//

import SwiftUI

struct DownloadImageView: View {
    
    @StateObject var loader:ImageLoadingViewModel
    init(url:String,key:String) {
        _loader = StateObject(wrappedValue: ImageLoadingViewModel(url: url, key: key))
    }
    var body: some View {
        ZStack{
            
            if loader.isLoading{
                
                ProgressView()
            }else if let image = loader.image{
                
               Image(uiImage: image)
                    .resizable()
                    .clipShape(Circle())
            }
            
        }
    }
}

#Preview {
    DownloadImageView(url: "https://fakestoreapi.com/img/81fPKd-2AYL._AC_SL1500_.jpg", key: "1")
        .frame(width: 75,height: 75)
        .previewLayout(.sizeThatFits)

}
