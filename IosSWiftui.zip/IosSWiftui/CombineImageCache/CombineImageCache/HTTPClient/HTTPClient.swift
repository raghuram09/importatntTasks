//
//  HTTPClient.swift
//  CombineImageCache
//
//  Created by Raghu on 13/03/24.
//

import Foundation
import Combine
enum NetworkError:Error{
    
    case noUrl
    case nodata
    case noresponce
    
}

class APIHandler{
    
    static let shared = APIHandler()
    
    @Published var productModels:[Product] = []
    private init() {
        
        getProducts()
    }
    
    var cancellable = Set<AnyCancellable>()
    
    func getProducts(){
        
        guard let urlStr = URL(string: "https://fakestoreapi.com/products") else{return}
        
        URLSession.shared.dataTaskPublisher(for: urlStr)
            .subscribe(on: DispatchQueue.global(qos: .background))
            .receive(on: DispatchQueue.main)
            .tryMap(handleOutput)
            .decode(type: [Product].self, decoder: JSONDecoder())
            .sink { res in
                
            } receiveValue: {[weak self] productsdata in
                
                self?.productModels = productsdata
            }
            .store(in: &cancellable)
        
    }
    
    private func handleOutput(outPut:URLSession.DataTaskPublisher.Output) throws ->Data{
        
        guard let responce  = outPut.response as? HTTPURLResponse,
              
                responce.statusCode >= 200 && responce.statusCode < 300 else{
            
            throw URLError(.badServerResponse)
        }
        return outPut.data
    }
    
}
