//
//  RowView.swift
//  CombineImageCache
//
//  Created by Raghu on 14/03/24.
//

import SwiftUI

struct RowView: View {
    
    var rowData:Product
    var body: some View {
     
        HStack{
            
            DownloadImageView(url: rowData.image ?? "", key: "\(rowData.id)")
                .frame(width: 75,height: 75)
            VStack(alignment: .leading){
                
                Text(rowData.title)
                    .font(.headline)
                Text(rowData.description)
                    .lineLimit(2)


            }
            .frame(maxWidth: .infinity,alignment: .leading)
            
        }
    }
}

#Preview {
    RowView(rowData: Product(id: 1, title: "raghu", price: 1.23, description: "hello how are you", category: "name", image: "https://fakestoreapi.com/img/81fPKd-2AYL._AC_SL1500_.jpg", rating: Rate(rate: 10, count: 5)))
        .padding()
        .previewLayout(.sizeThatFits)
}
