//
//  ProductCacheManager.swift
//  CombineImageCache
//
//  Created by Raghu on 14/03/24.
//

import Foundation

import SwiftUI

class ProductCacheManager{
    
    static let shared = ProductCacheManager()
    
    private init() {
        
        
    }
    
    var productImageCache:NSCache<NSString,UIImage> = {
        
        var cache = NSCache<NSString,UIImage>()
        cache.countLimit = 200
        cache.totalCostLimit = 1024 * 200 //200mb
        
        return cache
    }()
    
    func add(key:String,value:UIImage){
        
        productImageCache.setObject(value, forKey: key as NSString)
    }
    
    func get(key:String) -> UIImage?{
        
        return productImageCache.object(forKey: key as NSString)
    }
}
