//
//  ProductModelFileManager.swift
//  CombineImageCache
//
//  Created by Raghu on 14/03/24.
//

import Foundation
import SwiftUI

class ProductModelFileManager{
    
    static let shared = ProductModelFileManager()
    
    let folderName = "Downloaded_productsList"
    
    private init(){
        
        createFolderIfNeeded()
    }
    
    private func createFolderIfNeeded(){
        
        guard let url = getFolderPath() else {return}
        
        if !FileManager.default.fileExists(atPath: url.path){
            do{
                try FileManager
                    .default
                    .createDirectory(at: url, withIntermediateDirectories: true,attributes: nil)
                print("created folder")
                
            }catch let error{
                
                print("error creating folder \(error)")
            }
        }
    }
    
    private func getFolderPath() ->URL? {
        
        return FileManager
            .default
            .urls(for: .cachesDirectory, in: .userDomainMask)
            .first?
            .appendingPathComponent(folderName)
    }
    
    
    //downloadphotos
    
    
    private func getimagepath(key:String) ->URL?{
        
        guard let folder = getFolderPath() else{
            
            return nil
        }
        return folder.appendingPathComponent(key + ".png")
    }
    
    func add(key:String,value:UIImage){
        
        guard let data = value.pngData(),
              let url = getimagepath(key: key) else{return}
        
        do{
            
            try data.write(to: url)
            
        }catch let error{
            
            print("error saving  to file manager \(error)")
        }
    }
    
    func get(key:String) -> UIImage?{
        
        guard let url = getimagepath(key: key),
              FileManager.default.fileExists(atPath: url.path) else{
            return nil
        }
        
        return UIImage(contentsOfFile: url.path)
    }

}
