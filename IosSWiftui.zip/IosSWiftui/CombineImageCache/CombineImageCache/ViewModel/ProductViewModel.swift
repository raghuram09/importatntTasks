//
//  ProductViewModel.swift
//  CombineImageCache
//
//  Created by Raghu on 13/03/24.
//

import Foundation
import Combine
class ProductViewModel:ObservableObject{
    
    @Published var productsArray: [Product] = []
    
    var cancellable = Set<AnyCancellable>()
    let HTTPService = APIHandler.shared
    
    init() {
        
        addSubscribers()
    }
    
    func addSubscribers(){
        
        HTTPService.$productModels
            .sink { [weak self](returnProducts) in
                
                self?.productsArray = returnProducts
            }
            .store(in: &cancellable)
    }
}
