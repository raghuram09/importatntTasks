//
//  CombineMVVMApp.swift
//  CombineMVVM
//
//  Created by Apple on 09/01/24.
//

import SwiftUI

@main
struct CombineMVVMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
