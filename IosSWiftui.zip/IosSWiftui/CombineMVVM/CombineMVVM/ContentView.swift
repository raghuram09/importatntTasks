//
//  ContentView.swift
//  CombineMVVM
//
//  Created by Apple on 09/01/24.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var VM = ProductViewModel()
    var body: some View {
        VStack {

            List(VM.products) {productData in
                
                Text(productData.title ?? "")

            }
            
        }.onAppear(){
            
            VM.getProducts()
        }
       
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
