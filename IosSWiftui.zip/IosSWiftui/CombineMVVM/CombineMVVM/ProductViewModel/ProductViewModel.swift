//
//  ProductViewModel.swift
//  CombineMVVM
//
//  Created by Apple on 09/01/24.
//

import Foundation
import Combine

class ProductViewModel:ObservableObject{
    
    @Published var products: [Product] = []
    
    private var bag = Set<AnyCancellable>()
    
    func getProducts(){
        
        
        Apimanager.shared.getProductsData { responce  in
            
            
            switch responce{
                
                
            case .success(let products):
                
                
             
                self.products = products
                
                
            case.failure(let error):
                
                print(error)


            }
            
            
        }
    }
    
//    func fetchProducts(){
//        
//        
//        guard let url = URL(string: "https://fakestoreapi.com/products") else{
//            
//          return
//            
//        }
//        URLSession.shared.dataTaskPublisher(for: url)
//            .receive(on: DispatchQueue.main)
//            .map(\.data)
//            .decode(type: [Product].self, decoder: JSONDecoder())
//            .sink { res in
//                
//                
//            } receiveValue: { [weak self]  productsdata in
//                
//                self?.products = productsdata
//                
//                print(self?.products.count ?? "")
//            }
//            .store(in: &bag)
//
//
//
//
//
//        
//        
//    }

}
