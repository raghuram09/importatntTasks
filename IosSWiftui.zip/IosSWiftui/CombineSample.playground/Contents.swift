
import Combine

// Create a publisher that emits integers
let intPublisher = Just(42)

// Create a publisher that emits strings
let stringPublisher = Just("Hello, AnyPublisher!")

// Define a function that returns an AnyPublisher
func createUnifiedPublisher() -> AnyPublisher<Any, Never> {
    // Combine both publishers into a single AnyPublisher
    return Publishers.Merge(intPublisher.map { ($0) }, stringPublisher.map { ($0) }).eraseToAnyPublisher()
}

// Subscribe to the unified publisher
let unifiedPublisher = createUnifiedPublisher()

_ = unifiedPublisher.sink { value in
    if let intValue = value as? Int {
        print("Received an integer value: \(intValue)")
    } else if let stringValue = value as? String {
        print("Received a string value: \(stringValue)")
    }
}
