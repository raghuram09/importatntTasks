//
//  CoreDataDemoApp.swift
//  CoreDataDemo
//
//  Created by Raghu on 22/02/24.
//

import SwiftUI

@main
struct CoreDataDemoApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
