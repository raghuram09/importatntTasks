//
//  HTTPClient.swift
//  CoreDataDemo
//
//  Created by Raghu on 23/02/24.
//

import Foundation
enum NetworError :Error{
    
    case invaliUrl
    case invalidResponce
}


final class ApiHandler{
    
    func GetData<T: Decodable> (url:String) async throws -> T{
        
        guard let url = URL(string: url) else{
            
            throw NetworError.invaliUrl
        }
        let (data , responce ) = try await URLSession.shared.data(from: url)
        
        guard (responce as? HTTPURLResponse)?.statusCode == 200 else{
            
            throw NetworError.invalidResponce
        }
        return try JSONDecoder().decode(T.self, from: data)
    }
    
    
}
