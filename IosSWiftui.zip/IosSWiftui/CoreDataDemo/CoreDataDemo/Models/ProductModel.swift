//
//  ProductModel.swift
//  CoreDataDemo
//
//  Created by Raghu on 23/02/24.
//

import Foundation

struct Product:Decodable,Hashable{
    
    let id:Int?
    let title,description,category,image:String?
    let price:Double?
        
}

