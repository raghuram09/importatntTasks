//
//  ProductViewModel.swift
//  CoreDataDemo
//
//  Created by Raghu on 23/02/24.
//

import Foundation

import CoreData
@MainActor class productViewModel : ObservableObject{
    
    private let manager = ApiHandler()
    @Published var products : [Product] = []
    
    
    func saveDataInDatabase(context:NSManagedObjectContext){
        
        products.forEach{ (data) in
            
            let entity = Products(context: context)
            
            entity.title = data.title
            entity.desc = data.description
        }
        
        //saving all pending data at once
        
        do{
            
            try context.save()
            
        }catch{
            
            print(error.localizedDescription)
        }
        
        
    }
    
    func fetchProducts(context:NSManagedObjectContext) async{
        
        do {
            products = try await manager.GetData(url: "https://fakestoreapi.com/products")
            
           // print(products)
            
            
            //heigherOrderFunctions
            
            //filter
            
            let filterArray = products.filter{$0.price ?? 0 >= 50.0}
            
//            
  //          print(filterArray)
//            print("count is \(filterArray.count)")
            
            //map
            
            let mappedArray = products.map{$0.title ?? ""}
            
            
            print("map array is \(mappedArray)")

            //sort assending and decending
            
            let sortedArray = products.sorted { $0.price ?? 0 < $1.price ?? 0  }
            
            print("sorted array is \(sortedArray)")
//Reduce is total ammount and given offer price to minus or plus
            
            let reduceArray = products.reduce(-20, {$0 + ($1.price ?? 0)})
            
            print("reduce array is \(reduceArray)")

            
            self.saveDataInDatabase(context: context)
        } catch{
            
            
        }
    }
    
  
}
