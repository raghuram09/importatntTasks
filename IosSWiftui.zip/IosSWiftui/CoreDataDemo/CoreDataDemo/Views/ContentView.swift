//
//  ContentView.swift
//  CoreDataDemo
//
//  Created by Raghu on 22/02/24.
//

import SwiftUI
import CoreData

struct ContentView: View {
    
    
    @StateObject var viewModel = productViewModel()
    
    @Environment(\.managedObjectContext) var context
    
    @FetchRequest(entity: Products.entity(), sortDescriptors:[NSSortDescriptor(keyPath: \Products.title, ascending: true)]) var results:FetchedResults<Products>
    var body: some View {
        
        
        VStack{
            
            
            
            if results.isEmpty{
                if viewModel.products.isEmpty {
                    
                    ProgressView()
                }
                else{
                    List{
                        ForEach(viewModel.products,id: \.self){ productData in
                            
                            ProductRow(product: productData)
                            
                            
                        }
                    }
                    
                }
                
            }else{
                List{
                    
                    ForEach(results,id: \.self){ productData in
                        
                        ProductRow(fetchedData:productData)
                        
                    }
//                    .onDelete(perform: { indexSet in
//                        
//                        do{
//                            indexSet.forEach{ (indexRemoveData) in
//                                
//                                context.delete(indexRemoveData)
//                                
//                            }
//                            
//                            try context.save()
//                            
//                        }catch{
//                            
//                            print(error.localizedDescription)
//                        }
//                        
//                    })
                }
                
            }
            
            
            
        }
        
        
        .task {
            
            await viewModel.fetchProducts(context: context)
            
        }
        
    }
    
    
}


#Preview {
    ContentView()
}
