//
//  ProductRow.swift
//  CoreDataDemo
//
//  Created by Raghu on 23/02/24.
//

import SwiftUI
import CoreData
struct ProductRow: View {
    
    var product:Product?
    var fetchedData: Products?
    var body: some View {
       
        VStack{
            
            Text((product == nil ? fetchedData!.title! : product?.title)!)
                .font(.title2)
                .fontWeight(.heavy)
                .foregroundColor(.black)
            Text((product == nil ? fetchedData!.desc! : product?.description)!)
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(.gray)
            
        }
    }
}

