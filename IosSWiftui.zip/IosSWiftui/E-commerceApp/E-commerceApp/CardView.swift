//
//  CardView.swift
//  E-commerceApp
//
//  Created by Raghu on 05/03/24.
//

import SwiftUI

struct CardView: View {
    var body: some View {
        Text("Hello, Card!")
    }
}

#Preview {
    CardView()
}
