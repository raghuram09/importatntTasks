//
//  ContentView.swift
//  E-commerceApp
//
//  Created by Raghu on 02/03/24.
//

import SwiftUI

struct ContentView: View {
    
    @State var currentTab:Tab = .Home
    init(){
        
        UITabBar.appearance().isHidden = true
    }
    @Namespace var animation
    var body: some View {
   
        TabView(selection: $currentTab){
            
            

            if currentTab == Tab.Home{
                
                HomeView()

            }
            
            else if currentTab == Tab.Search{
                
                SearchView()
            }
            else if currentTab == Tab.Notification{
                
                NotificationsView()
            }
            else if currentTab == Tab.Cart{
                
                CardView()
            }
            
            else if currentTab == Tab.Profile{
                
                ProfileView()
                
            }
            
        }
        .overlay(
            
            HStack(spacing: 0){
                
                ForEach(Tab.allCases,id: \.rawValue){ tab in
                    
                    
                    TabButton(tab: tab)
                    
                    
                }
                .padding(.vertical)
                .padding(.bottom)
                .ignoresSafeArea()
                .background(Color(.secondarySystemBackground))
            },alignment: .bottom
        )
        .ignoresSafeArea(.all ,edges: .bottom)
    }
    
    func TabButton(tab : Tab) -> some View {
        
        GeometryReader{ proxy in
            
            
            Button(action: {
                withAnimation(.spring()){
                    
                    currentTab = tab
                }
                
            }, label: {
                VStack(spacing: 0){
                    
                    Image(systemName: currentTab == tab ? tab.rawValue + ".fill": tab.rawValue)
                        .resizable()
                        .foregroundColor(.gray)
                        .aspectRatio(contentMode: ContentMode.fit)
                        .frame(width: 25,height: 25)
                        .frame(maxWidth: .infinity)
                        .background{
                            
                            ZStack{
                                
                                if currentTab == tab{
                                    
                                    materialEffect(style: .light)
                                        .clipShape(Circle())
                                        .matchedGeometryEffect(id: "Tab", in: animation)
                                    
                                    Text(tab.Tabname)
                                        .foregroundColor(.primary)
                                        .font(.footnote)
                                        .padding(.top,50)
                                    
                                    
                                    
                                }
                            }
                        }
                        .contentShape(Rectangle())
                        .offset(y: currentTab == tab ? -15 : 0)
                }
            })
        }
        .frame(height: 25)
    }
}

#Preview {
    ContentView()
}


enum Tab:String,CaseIterable{
    
    case Home = "house"
    case Search = "magnifyingglass.circle"
    case Notification = "bell"
    case Cart = "bag"
    case Profile = "person"
    
    var Tabname:String{
        
        switch self {
            
        case .Home:
            return "Home"
        case .Search:
            
            return "Search"
            
        case .Notification:
            
            return "Notification"
            
        case .Cart:
            
            return "Cart"
            
        case .Profile:
            
            return "Profile"
        }
    }

}

//extension View{
//    
//    
//    func getSafeArea() -> UIEdgeInsets{
//        
//        guard let screen = UIApplication.shared.connectedScenes.first as? UIWindow else{
//            
//            return .zero
//        }
//        guard let safeArea = screen.wind.safeAreaInsets else{
//
//            return .zero
//        }
//        return safeArea
//    }
//    
//}

struct materialEffect:UIViewRepresentable{
    
    var style : UIBlurEffect.Style
    
    func makeUIView(context: Context) ->  UIVisualEffectView {
        
        let view = UIVisualEffectView(effect: UIBlurEffect(style: style))
        return view
    }
    
    func updateUIView(_ uiView: UIVisualEffectView, context: Context) {
        
    }
}
