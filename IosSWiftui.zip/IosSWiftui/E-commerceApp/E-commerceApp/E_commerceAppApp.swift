//
//  E_commerceAppApp.swift
//  E-commerceApp
//
//  Created by Raghu on 02/03/24.
//

import SwiftUI

@main
struct E_commerceAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
