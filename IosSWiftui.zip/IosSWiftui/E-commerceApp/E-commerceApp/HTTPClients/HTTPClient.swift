//
//  HTTPClient.swift
//  E-commerceApp
//
//  Created by Raghu on 07/03/24.
//

import Foundation

enum NetworkError:Error{
    
    case noUrl
    case nodata
    case noresponce

}

class APIHandler{
    
    static let shared = APIHandler()
    
    private init() {}
    
    
    func getProducts(url:String,completionHandler:@escaping(Result<[Product],NetworkError>) ->Void){
        
        
        guard let urlStr = URL(string: url) else{
            
            return completionHandler(.failure(.noUrl))
        }
        
        var request = URLRequest(url: urlStr)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { data, responce, error in
            
            guard let data = data ,error == nil else{
                
                return completionHandler(.failure(.nodata))
            }
            do {
                
                let products = try JSONDecoder().decode([Product].self, from: data)
                
                completionHandler(.success(products))
                
            }catch{
                
                return completionHandler(.failure(.noresponce))
                
            }
            
        }.resume()
        
        
    }
    
    
    
    
    // using genric
    
    func callForPostApi<T:Codable>( modelType: T.Type, paramters: Encodable, complesion:@escaping(Bool,Result<T, NetworkError>) -> Void) {
        
        guard let productUrl = URL(string: "https://fakestoreapi.com/products") else{
            
            return complesion(false,.failure(.noUrl))
        }
        
        
        URLSession.shared.dataTask(with: getRequest(url: productUrl) as URLRequest) { data, responce, error in
            
            guard let data = data, error == nil else {
                return complesion(false,.failure(.nodata))
            }
            //responcestatuscode check
            
            let statusCode = (responce as? HTTPURLResponse)?.statusCode
            
            if let statusCode1 = statusCode, 200...299 ~= statusCode1{
                
                //
                
            }
            
            do {
                let model = try JSONDecoder().decode(T.self, from: data)
                
                complesion(true,.success(model))
            }catch{
                
                complesion(false,.failure(.noresponce))
            }
            
        }.resume()
        
        
    }
    
    
    func getRequest(url: URL, timeOutInterval: TimeInterval = 30) -> NSMutableURLRequest {
        let theRequest = NSMutableURLRequest(url: url,
                                             cachePolicy: .reloadIgnoringLocalCacheData,
                                             timeoutInterval: timeOutInterval)
        
        theRequest.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        theRequest.addValue("MTYIOS", forHTTPHeaderField: "User-Agent")//useragent type
        
        theRequest.httpMethod = "GET"
        return addExtraHeadersIfNeeded(request: theRequest)
    }
    func postRequest(url: URL, parms: Encodable, timeOutInterval: TimeInterval = 30) -> NSMutableURLRequest {
        let theRequest = NSMutableURLRequest(url: url,
                                             cachePolicy: .reloadIgnoringLocalCacheData,
                                             timeoutInterval: timeOutInterval)
        
        theRequest.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        theRequest.addValue("MTYIOS", forHTTPHeaderField: "User-Agent")//useragent type
        //theRequest.addValue("application/pdf", forHTTPHeaderField: "Accept") // download request

        theRequest.httpMethod = "GET"
        do {
            
            let jsonBody = try JSONEncoder().encode(parms)
            theRequest.httpBody = jsonBody

        } catch{
            
        }
        return addExtraHeadersIfNeeded(request: theRequest)
    }
    var extraHeaders:KeyValuePairs <String,String>? = nil
    func addExtraHeadersIfNeeded(request: NSMutableURLRequest) -> NSMutableURLRequest {
        guard let moreHeaders = extraHeaders else {
            return request
        }
        for header in moreHeaders {
            request.addValue(header.value, forHTTPHeaderField: header.key)
        }
        return request
    }
}
