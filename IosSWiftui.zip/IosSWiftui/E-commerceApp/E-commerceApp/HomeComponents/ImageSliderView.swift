//
//  ImageSliderView.swift
//  E-commerceApp
//
//  Created by Raghu on 02/03/24.
//

import SwiftUI

struct ImageSliderView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ImageSliderView()
}
