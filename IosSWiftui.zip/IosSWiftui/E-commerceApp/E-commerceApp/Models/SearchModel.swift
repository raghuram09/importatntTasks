//
//  SearchModel.swift
//  E-commerceApp
//
//  Created by Raghu on 11/03/24.
//

import Foundation

struct SearchProduct: Codable{
    
    let id: Int
    let title: String
    let price:Float
    let description:String
    let category:String
    let image:String?
  
    
}

