//
//  LoadingView.swift
//  E-commerceApp
//
//  Created by Raghu on 09/03/24.
//

import SwiftUI

struct LoadingView: View {
    
    @State var animate = false
    var body: some View {
        
        VStack{
            
            Circle()
                .trim(from: 0,to: 0.9)
                .stroke(AngularGradient(gradient: .init(colors: [.red,.orange,.purple]), center: .center),style: StrokeStyle(lineWidth: 8,lineCap: .round))
                .frame(width: 60,height: 60)
                .rotationEffect(.init(degrees: self.animate ? 360 : 0))
                .animation(Animation.linear(duration: 0.7).repeatForever(autoreverses: false))
            
            Text("Please wait ...")
                .padding()
        }
        .padding(20)
        .background(Color.gray).opacity(0.8)
        .cornerRadius(10)
        .onAppear{
            self.animate.toggle()
        }
        
    }
}

#Preview {
    LoadingView()
}
