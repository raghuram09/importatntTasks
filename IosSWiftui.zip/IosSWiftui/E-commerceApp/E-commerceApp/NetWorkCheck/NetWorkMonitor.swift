//
//  NetWorkMonitor.swift
//  E-commerceApp
//
//  Created by Raghu on 08/03/24.
//

import Foundation

import Network

class NetWorkMonitor :ObservableObject{
    
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "Monitor")
    @Published var isActive = false
    @Published var isExpensive = false
    @Published var isContrained = false
    @Published var connectionType = NWInterface.InterfaceType.other
    
    
    var conectionDescription:String {
        
        if isActive {
            return "internet Connected"
        }else{
            
            return "No internet Connected"

        }
        
    }
    init(){
        
        monitor.pathUpdateHandler = { Path in
            
            DispatchQueue.main.async {
                
                
                self.isActive = Path.status == .satisfied
                self.isExpensive  = Path.isExpensive
                self.isContrained  = Path.isExpensive

                let connectionType:[NWInterface.InterfaceType] = [.cellular,.wifi,.wiredEthernet]
                
                self.connectionType = connectionType.first(where: Path.usesInterfaceType) ?? .other
                
            }
        }
        monitor.start(queue: queue)
    }


    
}
