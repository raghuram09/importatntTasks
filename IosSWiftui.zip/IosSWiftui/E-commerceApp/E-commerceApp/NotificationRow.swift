//
//  NotificationRow.swift
//  E-commerceApp
//
//  Created by Raghu on 16/03/24.
//

import SwiftUI

struct NotificationRow: View {
    
    var notificationRowData:SearchProduct
    
    var body: some View {

        VStack(alignment: .leading){
            
            Text(notificationRowData.title)
                .font(.headline)
                .lineLimit(1)
            
            HStack{
                Text("$\(notificationRowData.price)")
                Spacer()
                
            }
        }
        .foregroundColor(.white)
        .padding()
        .background(Color.blue.cornerRadius(10))
        .padding(.horizontal)
    }
}

#Preview {
    NotificationRow(notificationRowData: SearchProduct(id: 1, title: "", price: 10.5, description: "", category: "", image: ""))
}
