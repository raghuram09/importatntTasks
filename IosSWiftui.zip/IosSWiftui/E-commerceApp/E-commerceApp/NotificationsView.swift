//
//  NotificationsView.swift
//  E-commerceApp
//
//  Created by Raghu on 05/03/24.
//

import SwiftUI

protocol notificationData{
    
    func NotificationsuccessResponce(responce:[SearchProduct])
}

struct NotificationsView: View {
    
    @ObservedObject var NViewModel = SearchviewModel()
    
    var filterPopArray = ["bellow 10","above 10","above 50"]
    
    
    @State var productData:[SearchProduct] = []
    @State var filterdArray:[SearchProduct] = []
    
    
    @State var show  = false
    
    private var finalproducts:[SearchProduct]{
        filterdArray.isEmpty ?productData : filterdArray
    }
    
    var body: some View {
        NavigationStack{
            
            SearchView(SDelegate: self)
            VStack(spacing: 0){
                
                List{
                    
                    ForEach(finalproducts,id: \.id){ rowData in
                        
                        
                        VStack(alignment: .leading){
                            
                            Text(rowData.title)
                                .font(.headline)
                                .lineLimit(1)
                            
                            HStack{
                                Text("Price $\(rowData.price)")
                                
                                Text("Id: \(rowData.id)")
                                Spacer()
                                
                            }
                        }
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue.cornerRadius(10))
                        .padding(.horizontal)
                    }
                    .listRowSeparator(.hidden)
                    
                    
                }
                .listStyle(.plain)
            }
            .onAppear{
                
                
            }
            .toolbar{
                
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: {
                        
                        withAnimation{
                            
                            self.show.toggle()
                        }
                        
                    }, label: {
                        
                        Image(systemName: "line.3.horizontal.decrease.circle")
                    })
                }
            }
            
            if self.show {
                
                
                
                GeometryReader{_ in
                    
                    listView()
                    
                    
                }.background(
                    Color.black.opacity(0.6)
                    
                        .onTapGesture {
                            withAnimation{
                                
                                self.show.toggle()
                                
                            }
                        }
                    
                )
            }
            
        }
        
    }
    
    @ViewBuilder
    func listView() -> some View {
        
        VStack{
            
            List{
                
                ForEach(filterPopArray,id: \.self){rowdata in
                    
                    
                    Text(rowdata)
                        .font(.title)
                        .onTapGesture {
                            show = false
                            filterdArray = productData.filter({ (user) -> Bool in
                                
                                return user.price < 50
                            })
                            
                            print("count is ....\(filterdArray.count)")
                        }
                    
                    
                }
                
            }
        }
        .padding()
        
    }
    
    
}

#Preview {
    NotificationsView()
}


extension NotificationsView:notificationData{
    func NotificationsuccessResponce(responce: [SearchProduct]) {
        
        print("....Notification\(responce)")
        productData = responce
    }
    
}


