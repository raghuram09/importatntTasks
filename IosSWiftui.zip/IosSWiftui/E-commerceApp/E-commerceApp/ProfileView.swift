//
//  ProfileView.swift
//  E-commerceApp
//
//  Created by Raghu on 05/03/24.
//

import SwiftUI

struct settingOptions:Hashable{
    
    var sessionName:String
    
    var optionsData: [SettingsData] = []
    
}


struct SettingsData:Hashable{
    
    var name:String?
    
    var image :String?
}



struct ProfileView: View {
    
    
    var settingsOptionData = [
        
        settingOptions(sessionName: "Profile",optionsData: [
             SettingsData(name: "Account Mode", image: "person"), SettingsData(name: "accessibility", image: "accessibility"), SettingsData(name: "Edit", image: "pencil"), SettingsData(name: "Account Mode", image: "person"), SettingsData(name: "Account Mode", image: "person")
        ]),settingOptions(sessionName: "Account Settings",optionsData: [
            SettingsData(name: "LogOut", image: ""),SettingsData(name: "Delete Account", image: "")
        ])
        
        
        
    ]
    
    
    var body: some View {
        
        VStack{
            
            VStack{
                Image(systemName: "person.circle.fill")
                    .resizable()
                    .frame(width: 80, height: 80)
                Text("RaghuRamReddy")
                    .font(.system(size: 25))
                    .fontWeight(.bold)
            }
            List{
                
                ForEach(settingsOptionData ,id: \.self) { sessionSettings in
                    
                    Section(header: Text(sessionSettings.sessionName)){
                        
                        
                        ForEach(sessionSettings.optionsData,id: \.self){ optionSettings in
                            HStack{
                                Image(systemName: optionSettings.image ?? "")
                                Text(optionSettings.name ?? "")
                                
                                Spacer()
                                
                                Image(systemName: "pencil")
                                    .resizable()
                                    .padding(.trailing,10)
                                 .frame(width: 30, height: 30, alignment: .trailing)

                            }
                            
                        }
                    }


                }
            }
        }
        
    }
}

#Preview {
    ProfileView()
}
