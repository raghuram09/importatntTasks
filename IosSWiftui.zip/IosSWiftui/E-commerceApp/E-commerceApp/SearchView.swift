//
//  SearchView.swift
//  E-commerceApp
//
//  Created by Raghu on 05/03/24.
//

import SwiftUI

enum NetworkCheck: CaseIterable {
    case isActive, isContrained, isExpensive
}

protocol viewControllerDelegate {
   
   func successResponce(responce:[SearchProduct])
   func failureResponce(error: NetworkError?)
   
}

struct SearchView: View {
    
    @StateObject private var networkMonitor = NetWorkMonitor()
    @ObservedObject var viewModel = ProductViewModel()

    @ObservedObject var SViewModel = SearchviewModel()
    
    var SDelegate:notificationData?

    var body: some View {
        
        VStack{
            if networkMonitor.isActive{
                
            }else{
                
                Text(networkMonitor.conectionDescription)
            }
            
        }.onAppear{
            SViewModel.vcDelegate = self

            SViewModel.getProductsList()
        }
    }
}

#Preview {
    SearchView()
}
extension SearchView:viewControllerDelegate{
    func successResponce(responce: [SearchProduct]) {
        
       // print("successResponce \(responce)")
        
        SDelegate?.NotificationsuccessResponce(responce: responce)

    }
    
    func failureResponce(error: NetworkError?) {
        print("failureResponce \(String(describing: error?.localizedDescription))")
        
    }
    
    
 
    
}
