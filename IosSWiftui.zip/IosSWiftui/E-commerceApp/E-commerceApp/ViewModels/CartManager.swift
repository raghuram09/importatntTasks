//
//  CartManager.swift
//  E-commerceApp
//
//  Created by Raghu on 08/03/24.
//

import Foundation

class CartManager :ObservableObject{
    
    
    @Published private  var products:[Product] = []
    @Published private  var total :Int = 0
    
    
    func addtoCart(product:Product) {
        
        products.append(product)
        total += Int(product.price)
    }
    
    func removeFromCart(product:Product){
        
        products = products.filter{ $0.id != product.id}
        total -= Int(product.price)
    }

    
}
