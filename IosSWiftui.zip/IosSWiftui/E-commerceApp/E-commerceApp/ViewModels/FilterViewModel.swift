//
//  FilterViewModel.swift
//  E-commerceApp
//
//  Created by Raghu on 09/03/24.
//

import Foundation

enum PopularFilters : String,CaseIterable,Codable{
    case breakfast = "Breakfast"
    case parking = "Parking"
    case wifi = "Wifi"

    
}
class FilterViewModel :ObservableObject{
    
    @Published var price :Double = 100.0
    @Published var rating :Int?
    @Published var papularFilter : [PopularFilters] = []


}


extension FilterViewModel{
    
    func containsFilter(_ filter:String) -> Bool{
        
        return papularFilter.contains {$0.rawValue == filter}
    }
}
