//
//  ProductViewModel.swift
//  E-commerceApp
//
//  Created by Raghu on 07/03/24.
//

import Foundation

class ProductViewModel:ObservableObject{
    
    @Published var products: [Product] = []
    
    @Published var productArray: [Product] = []

    
    var vcDelegate:viewControllerDelegate?

    func getProductsList(){
        let productUrl = "https://fakestoreapi.com/products"
        
        APIHandler.shared.getProducts(url: productUrl) { [self] productResponce in
            
            switch productResponce{

            case .success(let productsList):

                DispatchQueue.main.sync {
                    self.products = productsList
                    
                }
                 // print(self.products)


            case.failure(let error ):

                print(error)
                                
            }
            
        }
    }
}
