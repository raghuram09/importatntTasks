//
//  SearchViewModel.swift
//  E-commerceApp
//
//  Created by Raghu on 11/03/24.
//

import Foundation

protocol MyProtocol {
    var optionalProperty: String? { get set }
}

extension MyProtocol {
   
    var optionalProperty: String? {
           return nil
       }
}

class SearchviewModel:ObservableObject{
    
    @Published var searchproducts: [SearchProduct] = []
    
    var vcDelegate:viewControllerDelegate?

    func getProductsList(){
        
        let parames = ["":""]

        APIHandler.shared.callForPostApi(modelType: [SearchProduct].self, paramters: parames) { isSuccuss, result in
            
            
            switch result{
           
                       case .success(let products):
           
                          // completion(.success(products))
           
                           self.vcDelegate?.successResponce(responce: products)
           
                       case.failure(let error):
           
                          // completion(.failure(.message(error)))
                self.vcDelegate?.failureResponce(error: .noresponce)
                      
            }
            
            
        }
    }
}
