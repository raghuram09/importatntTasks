//
//  CartView.swift
//  E-commerceApp
//
//  Created by Raghu on 08/03/24.
//

import SwiftUI

struct CartView: View {

    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    CartView()
}
