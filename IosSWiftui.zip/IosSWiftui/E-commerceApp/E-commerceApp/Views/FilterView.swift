//
//  FilterView.swift
//  E-commerceApp
//
//  Created by Raghu on 09/03/24.
//

import SwiftUI

struct filterviewstate{
    
    var price:Double = 100.0
    var rating:Int?
    var popularFilters:[PopularFilters] = []
}

struct FilterView: View {
    
    @Environment(\.dismiss) var dismiss
    @State private var price:Double = 100
    
    @StateObject private var vm :FilterViewModel
    var onfilterApplied:(filterviewstate) -> Void
    
    init(vm:FilterViewModel,onfilterApplied:@escaping(filterviewstate) -> Void){
        
        _vm = StateObject(wrappedValue: vm)
        self.onfilterApplied = onfilterApplied
    }
    var body: some View {

        VStack(alignment: .leading){
            Text("Filters")
                .font(.title)
                .fontWeight(.bold)
            Spacer().frame(height: 100)
            TextField("Amount", value: $price, format: .currency(code: Locale.current.currency?.identifier ?? "USD"))
                .fontWeight(.bold)
            
            Slider(value: $vm.price,in: 0...500, step: 1.0)
            
            Text("Popular Filters")
            
                .font(.title)
                .fontWeight(.bold)
                .padding(.top,40)
                .padding(.bottom,10)
            
            ForEach(PopularFilters.allCases,id: \.self) { filter in
                HStack{
                    
                    Image(systemName: vm.containsFilter(filter.rawValue) ? "checkmark.square.fill" : "square")
                        .onTapGesture {
                            if !vm.containsFilter(filter.rawValue){
                                
                                vm.papularFilter.append(filter)
                            }else{
                                vm.papularFilter.removeAll{$0.rawValue == filter.rawValue}
                            }
                        }
                    Text(filter.rawValue)
                }
                
            }
            
            Text("Rating")
                .fontWeight(.bold)
                .padding(.top,40)
            HStack{
                ForEach(1...5,id: \.self) { rating in
                    
                    Rectangle()
                        .frame(width: 50,height: 50)
                    
                }
            }
            
            Button(action: {
                
                let vs = filterviewstate(price: vm.price,rating: vm.rating,popularFilters: vm.papularFilter)
                onfilterApplied(vs)
                dismiss()
            }, label: {
            Text("Apply")
             .frame(maxWidth: .infinity,maxHeight: 44)
            })
            .padding(.top,40)
            .buttonStyle(.borderedProminent)
            
            Spacer()
        }.padding()
    }
}

#Preview {
    FilterView(vm: FilterViewModel()){ _ in
        
    }
}
