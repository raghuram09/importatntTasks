//
//  HomeView.swift
//  E-commerceApp
//
//  Created by Raghu on 02/03/24.
//

import SwiftUI


struct HomeView: View {
    
    @ObservedObject var viewModel = ProductViewModel()
    @StateObject private var networkMonitor = NetWorkMonitor()

    
//    @Environment var products:ProductViewModel
    
    @StateObject var cartManger = CartManager()
    @State private var ispresented:Bool = false
    

    
    var colums:[GridItem]  = [
        GridItem(.flexible(),spacing:nil,alignment:nil),
        GridItem(.flexible(),spacing: nil,alignment: nil)]
    var body: some View {
        NavigationStack{
            ScrollView{
                LazyVGrid(columns: colums){
                    if networkMonitor.isActive{
                        if viewModel.products.count > 0{
                            
                            
                            ForEach(viewModel.products,id: \.id){ productRowData in
                                
                                RowItem(productdata: productRowData)
                                
                            }
                        }else{
                            
                            Text("No data")
                        }
                        
                    }else{
                        
                        Text("No internet  ")
                    }
                    
                 
                }
                .padding()
            }
            .navigationTitle("Products")
            .toolbar{
                
                Button(action: {
                    ispresented = true

                    
                }, label: {

                  Image(systemName: "line.3.horizontal.decrease.circle")
                })

            }
            .sheet(isPresented: $ispresented, content: {
              
                FilterView(vm: FilterViewModel(), onfilterApplied: { vsData in
                    
                    print(vsData)
                })
                    .presentationDetents([.medium,.large,.fraction(0.25),.height(700)])
            })
        }
        
       
        .task {
            viewModel.getProductsList()
            


        }
    }
}

#Preview {
    HomeView()
}
