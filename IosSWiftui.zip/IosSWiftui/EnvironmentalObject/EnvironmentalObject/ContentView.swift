//
//  ContentView.swift
//  EnvironmentalObject
//
//  Created by Raghu on 11/03/24.
//

import SwiftUI

struct dataArray:Hashable{
    
    var name:String?
    var age:Int
}

struct ContentView: View {
    
    
    @StateObject var data = ViewModelData()
    var body: some View {
        VStack {
            
            ThirdView()
            SecondView()
            
            fourthview()
         
        }
        .environmentObject(data)
      
    }
}

#Preview {
    ContentView()
}
