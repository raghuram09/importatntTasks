//
//  EnvironmentalObjectApp.swift
//  EnvironmentalObject
//
//  Created by Raghu on 11/03/24.
//

import SwiftUI

@main
struct EnvironmentalObjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
