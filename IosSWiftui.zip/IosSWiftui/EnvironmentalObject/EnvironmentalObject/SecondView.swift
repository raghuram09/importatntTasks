//
//  SecondView.swift
//  EnvironmentalObject
//
//  Created by Raghu on 11/03/24.
//

import SwiftUI

struct SecondView: View {
    
    @EnvironmentObject var data: ViewModelData
    
    var newdata = dataArray(name: "sandhya", age: 29)
    var body: some View {
        ZStack{
            
            Rectangle()
                .frame(width: 200,height: 60)
                .foregroundColor(.blue)
                .cornerRadius(10)
            
            Text("minus \(data.text) : \(data.Counter)")
                .foregroundColor(.white)
            
        }
        .onTapGesture {
            data.Counter -= 1
            data.addedstudent.append(newdata)
        }
        
    }
}

#Preview {
    SecondView()
        .environmentObject(ViewModelData())
}
