//
//  ThirdView.swift
//  EnvironmentalObject
//
//  Created by Raghu on 11/03/24.
//

import SwiftUI

struct ThirdView: View {
    
    @EnvironmentObject var data:ViewModelData
    
    var newdata = dataArray(name: "Gaganasri", age: 1)

    var body: some View {
        ZStack{
            
            Rectangle()
                .frame(width: 200,height: 60)
                .foregroundColor(.blue)
                .cornerRadius(10)
            
            Text(" plus\(data.text) : \(data.Counter)")
                .foregroundColor(.white)
            
        }
        .onTapGesture {
            data.Counter += 1
            
            data.addedstudent.append(newdata)

            
        }
    }
}

#Preview {
    ThirdView()
            .environmentObject(ViewModelData())

}
