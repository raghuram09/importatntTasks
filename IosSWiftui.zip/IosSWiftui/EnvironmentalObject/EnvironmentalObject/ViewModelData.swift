//
//  ViewModelData.swift
//  EnvironmentalObject
//
//  Created by Raghu on 11/03/24.
//

import Foundation

class ViewModelData:ObservableObject{
    
    @Published var text = "Counter"
    @Published var Counter  = 0
    
    @Published var students = [dataArray]()
    
    
    var addedstudent = [dataArray(name: "raghu", age: 29),dataArray(name: "rajini", age: 26)]

}
