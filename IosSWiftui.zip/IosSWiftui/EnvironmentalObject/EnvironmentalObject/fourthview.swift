//
//  fourthview.swift
//  EnvironmentalObject
//
//  Created by Raghu on 11/03/24.
//

import SwiftUI

struct fourthview: View {
    
    @EnvironmentObject var data:ViewModelData

    var body: some View {
     
        VStack{
            
            List{
                ForEach(data.addedstudent,id: \.self) { student in
                    
                    Text(student.name ?? "")
                    
                }
            }
        }
        
    }
}

#Preview {
    fourthview()
        .environmentObject(ViewModelData())
}
