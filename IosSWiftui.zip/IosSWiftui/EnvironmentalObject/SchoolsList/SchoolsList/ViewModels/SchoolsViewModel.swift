//
//  SchoolsViewModel.swift
//  SchoolsList
//
//  Created by Raghu on 29/02/24.
//

import Foundation

@MainActor class SchoolListViewModel:ObservableObject{
    
    @Published var schoolsList = [schoolsModel]()
    
    func  schoolsListData() {
        
        
        ApiHandler.shared.getSchoolsList { responce in
            
            switch responce{
                
            case .success(let schoolsListRes):
                
                DispatchQueue.main.async {
                    self.schoolsList = schoolsListRes
                    
                    print(self.schoolsList)
                }
             
                
            case .failure(let error):
                
                print(error.localizedDescription)
            }
            
        }
    }
}
