//
//  ContentView.swift
//  SchoolsList
//
//  Created by Raghu on 29/02/24.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var viewmodel = SchoolListViewModel()
    //    @ObservedObject var router = NavRouter()
    
    @State private var filteredProducts:[schoolsModel] = []
    
    private var finalproducts:[schoolsModel]{
        
        filteredProducts.isEmpty ?viewmodel.schoolsList : filteredProducts
    }
    
    @State var search:String = ""
    
    @State private var path = [String]()
    
    
    var body: some View {
        
        NavigationStack{
                VStack(alignment: .leading) {
                    
                        List{
                            
                            ForEach(finalproducts,id: \.dbn){ schoolObject in
                                
//                                    .listRowInsets(.init(top: 0, leading: 0, bottom: 0, trailing: 0))
                                
                                NavigationLink(value: schoolObject) {
                                    
                                    SchoolRowView(eachProduct:schoolObject )
                                }
                                
                            }
                 
                    }
                        .listStyle(.plain)
                    
                }
                .navigationDestination(for: schoolsModel.self) { value in
                    
                    SchoolDetailView(eachProductdetail: value)
                }

        }
        
//        .padding()
        .ignoresSafeArea()

        .searchable(text: $search )
        .onChange(of: search) {
            performSearch(keyword: search)
        }
        
        .onAppear(){
            viewmodel.schoolsListData()
            
        }
        
        
    }
    
    private func performSearch(keyword:String){
        
        filteredProducts = viewmodel.schoolsList.filter { schoolData in
            
            schoolData.school_name!.contains(keyword)
            
            
        }
        print(filteredProducts.count)
        
    }
}

#Preview {
    ContentView()
}
