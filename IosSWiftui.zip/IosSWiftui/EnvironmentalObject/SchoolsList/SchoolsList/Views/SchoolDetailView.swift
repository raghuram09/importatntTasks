//
//  SchoolDetailView.swift
//  SchoolsList
//
//  Created by Raghu on 29/02/24.
//

import SwiftUI

struct SchoolDetailView: View {
    
    var eachProductdetail:schoolsModel
    
    var body: some View {
     
        VStack{
            Text(eachProductdetail.dbn ?? "")
            Text(eachProductdetail.school_name ?? "")
        }
    }
}

