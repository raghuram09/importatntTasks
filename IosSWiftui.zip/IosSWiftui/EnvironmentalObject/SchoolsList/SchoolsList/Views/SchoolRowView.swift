//
//  SchoolRowView.swift
//  SchoolsList
//
//  Created by Raghu on 29/02/24.
//

import SwiftUI

struct SchoolRowView: View {
    let eachProduct:schoolsModel
    
    var body: some View {
      
        VStack(alignment: .leading){
            Text("Id: \(eachProduct.dbn ?? "")")
                .font(.system(size: 20))
                .fontWeight(.bold)
            Text(eachProduct.school_name ?? "")
                .font(.title3)
                .fontWeight(.bold)
            
            
        }
        
    }
}

