import UIKit


//AND OR OR LOGICS



var a=20;
var b=true;
var c=20;
var d=false;
var e="raghu"

var f=4;


//if a >= 10{
//
//    debugPrint("first")
//}else if a <= 11{
//
//    debugPrint("second")
//}else{
//
//    debugPrint("third")
//}


//// by using "OR" condition any one value is true output comes true
//debugPrint(a == 10 || c == 12 && f == 10   )
//
//
//// by using "AND" condition  TWO values is true then output will true otherwise it will return false
//
//debugPrint(a == 10 && c == 20 )
//
//
//
//debugPrint(a == 10 || c == 5 && f == 10)




//ternary conditio

//Here, the ternary operator evaluates condition and
//
//if condition is true, expression1 is executed.
//if condition is false, expression2 is executed.

// program to check pass or fail
//let marks = 60
//
//// use of ternary operator
//let result = (marks <= 40) ? "pass" : "fail"
//
//print("You " + result + " the exam")
//
//let result2 = b ? 10 : 20
//
//debugPrint(result2)
// even and odd numbers

//for i  in 0...100{
//
//
//    if (i % 2 == 0){
//
//       // debugPrint(i)
//    }
//}
//

//MARK::-particular Numbers is prime


//let number = 7
//var isItPrime: Bool = true
//for i in 2 ..< number {
//    if number % i == 0 {
//        isItPrime = false
//    }
//}
//print(isItPrime)

//MARK::-PRIMENUMBERS


//for i in 1..<100 {
//    var count = 0
//    for j in 1..<i {
//        if i % j == 0 {
//            count += 1
//        }
//    }
//    if count <= 1 {
//        print(i, "is prime")
//    }
//
//}




// removie duplicates values

//var arr = [Int]()
//var dup=[1,2,3,4,4,4,1,5,4,6,7,6]
//for i in dup{
//    if !arr.contains(i){
//        arr.append(i)
//    }
//}
//print(arr)

// list of arrays values equal values get


//let fg = ["A","B","I","D","O"];
//
//var VovelValue = ["A","E","I","O","U"]
//
//        for i in VovelValue {
//            for j in fg {
//
//                if i == j
//                {
//                    finalValue.append(i)
//                }else{
//                }
//            }
//        }
//        print("\(finalValue)")

//MARK:- FIND PRIME NUMBERS BETWEEN NUMBERS

//for i in 0..<numk.count {
//    var count = 0
//    for j in 1..<numk[i] {
//        if (numk[i]) % j == 0 {
//            count += 1
//        }
//    }
//    if count <= 1 {
//        print(numk[i], "is prime")
//    }
//
//}


//MARK::-TABLES

//        for i in 1..<20{
//
//            for j in 1..<10{
//
//               // print("\(i * j) = \(i * j)")
//                print("\(i) * \(j) = \(i * j)")
//
//
//            }
//
//
//
//        }


 //repeted index find in array how many times

let arr = ["FOO", "FOO", "BAR", "FOOBAR"]
var counts: [String: Int] = [:]

for item in arr {
    counts[item] = (counts[item] ?? 0) + 1
}
//
print(counts)  // "[BAR: 1, FOOBAR: 1, FOO: 2]"
//
//for (key, value) in counts {
//    print("\(key) occurs \(value) time(s)")
//}
// second way of repeted index find in array how many times

//let arr = ["FOO", "FOO", "BAR", "FOOBAR"]
//let counts = arr.reduce(into: [:]) { counts, word in counts[word, default: 0] += 1 }
//
//print(counts)  // ["BAR": 1, "FOOBAR": 1, "FOO": 2]

//GenricWithClusure return any type


//func addValues<T>(a:T) ->T{
//
//    return a
//}
//
//addValues(a: "0.123")
//
//
let data=[[1,2,3],[1,2,[2,4]],[1,2,[3,4,[6,7]]]]

// let  array = data.flat(3);

data.flatMap{ $0 }
let y = data.flatMap({$0})

let arr12 = data.flatMap { $0 }

let arra2 = arr12.flatMap { $0 }

print(arra2)


protocol Player{
    
    var name:String {get set}
    var score:Int {get set}
    var nickName:String{get}
    
}

struct Person:Player{
    var name: String
    
    var score: Int
    
    var nickName: String{
        
        return "ram"
    }
    
    
    
}

var person = Person(name: "pitt", score: 500)
person.name = "pedro"
