import UIKit
var array = [10, 12,40,48,50,38,19]

// largest
let largest = array.max()

//find index
let indexFind = array.firstIndex(where: {$0 == largest})

print(indexFind ?? 0)
//sorting
var sortedarray = array.sorted() {$0 > $1}

var secondLargestNub = sortedarray[1]

print(secondLargestNub)

// repeted values find
let x = [1, 1, 2, 3, 4, 5, 5, 6 , 6]

let setValue = Set(x)
print("remove the duplicates \(setValue)")
//let duplicates = Array(Set(x.filter({ (i: Int) in x.filter({ $0 == i }).count > 1})))

let value = x.map{$0}
print(value)
// reomve the njull values
let numbers = ["42", "19", "notANumber"]
let ints = numbers.compactMap { Int($0) }
print(ints)


let repetedArrat = Array(Set(x.filter({(i : Int) in x.filter({$0 == i }).count > 1})))

print(repetedArrat.sorted() {$0 < $1})


//repeted values counts

let repeetedArraytems = [1,1,1,3,3,5,6,7,7,8,4,4]

var repeetedsortedarray = repeetedArraytems.sorted() {$0 > $1}

let mappedItems = repeetedsortedarray.map { ($0, 1) }

let counts = Dictionary(mappedItems, uniquingKeysWith: +)
print(counts)

// get odd num and add that values

//func sumofOddElements(arr:[Int])->Int{
//
//    var result = 0
//
//    var oddarr = arr.filter{$0 % 2 == 1}
    
//    if oddarr.count == 0{
//
//        return result
//    }else{
//
//        for item in oddarr{
//
//            result += item
//        }
//    }
    
   // return arr.filter{$0  % 2 == 1}.reduce(0){$0 + $1}
   // return result
//}

//print(sumofOddElements(arr: [12,133,113,1242,111]))
//swap two variables withou taking third varibale
var Number1 = 30
var Number2 = 59
Number1 = Number1 + Number2
Number2 = Number1 - Number2
Number1 = Number1 - Number2

print("Number 1 after swapping:", Number1)
print("Number 2 after swapping:", Number2)

func findSecondLargest(arr:[Int]) -> Int{
var firstLargest = 0
var secondLargest = 0
for index in 0..<arr.count{
    
    let val = arr[index]
    print(val)
    
    if val > firstLargest {
        
        secondLargest = firstLargest
        
        firstLargest = val
    }
}
return secondLargest

}

let nub = findSecondLargest(arr: [1,2,4,7,8,9])

print(".....\(nub)")

let number = 7
var isItPrime: Bool = true
for i in 2 ..< number {
    if number % i == 0 {
        isItPrime = false
    }
}
print(isItPrime)

//MARK::-PRIMENUMBERS


for i in 1..<100 {
    var count = 0
    for j in 1..<i {
        if i % j == 0 {
            count += 1
        }
    }
    if count <= 1 {
        print(i, "is prime")
    }

}




// removie duplicates values

var arr = [Int]()
var dup=[1,2,3,4,4,4,1,5,4,6,7,6]
for i in dup{
    if !arr.contains(i){
        arr.append(i)
    }
}
print(arr)


func sumofOddElements(arr:[Int])->Int{

    var result = 0

//    var oddarr = arr.filter{$0 % 2 == 1}
//    
//    if oddarr.count == 0{
//
//        return result
//    }else{
//
//        for item in oddarr{
//
//            result += item
//        }
//    }
    
    return arr.filter{$0  % 2 == 1}.reduce(0){$0 + $1}
//    return result
}

print(sumofOddElements(arr: [1,2,3,4,5,6]))
