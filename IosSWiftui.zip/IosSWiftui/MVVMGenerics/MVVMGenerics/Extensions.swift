//
//  Extensions.swift
//  MVVMGenerics
//
//  Created by Apple on 29/11/23.
//

import Foundation

extension URL{
    
    static func productURL() ->URL?{

        return URL(string: "https://fakestoreapi.com/products")
        
    }
    
}

