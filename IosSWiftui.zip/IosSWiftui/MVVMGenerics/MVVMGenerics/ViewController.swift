//
//  ViewController.swift
//  MVVMGenerics
//
//  Created by Apple on 29/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    var productsModel:[Product]?
    
    var viewModel = productViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        getProductsRes()
           
    }
    
    
    func getProductsRes(){
        
        viewModel.getProductsList { responce in
        switch responce{
            
            
        case .success(let products):
            
             print(products)
            self.productsModel = products
            
            
        case.failure(let error):
            
            print(error)
            
            
            
        }
    }
        
        
    }
    
    
    
}


