//
//  productViewModel.swift
//  MVVMGenerics
//
//  Created by Apple on 30/11/23.
//

import Foundation


class productViewModel{
    
    
    func getProductsList(completion:@escaping(Result<[Product],networkError>) ->Void) {

        //let parames:[String: Encodable] = userProduct(id: 10, title: "raghu", price: 10.1)

        //let parames:[String: Encodable] = [:]

        let parames = ""



        HTTPClient.shared.callForPostApi(urlString:"https://fakestoreapi.com/products", modelType: [Product].self, paramters:parames) { isSuccuss, result in


            switch result{

            case .success(let products):

                completion(.success(products))

            case.failure(let error):

                completion(.failure(.message(error)))
            }


        }

    }
}
