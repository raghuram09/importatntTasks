//
//  ViewController.swift
//  MultiThreading
//
//  Created by Raghu on 01/03/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var countLbl: UILabel!
    var array:[TimeInterval] = [1 , 2 ,3 ,5,8]
    
    var myArray = [1,3,5,6,7,9]
    
    var  threds:Array<Any> = []
    override func viewDidLoad() {
        super.viewDidLoad()
        //mySerialQueue()
       // myConcurentQueue()
        
        getdata()
  
        
    }
    
    
    //closure Function
    func getDataTask(completion:@escaping(String) -> Void ){
        
        
        completion("raghu")
        
    }
    
    func getdata(){
        
        threds = [T1(),T2(),T3()]
        let group = DispatchGroup()
        
        for number in threds {
            
            group.enter()
            
            print("entering the groupo")
            DispatchQueue.global().asyncAfter(deadline: .now() + 3, execute: {
                
                group.leave()
                
                print("leaving group \(number)")
            })
        }
        
        group.notify(queue: .main) {
            
            print("done all operations")
        }
    }

    @IBAction func startBtn(_ sender: Any) {
        
        let concurentQueue1 = DispatchQueue.global()
        
        
        concurentQueue1.async { [weak self] in
 
            for i in 1...100000{
                
                print("T1.. \(i)")
                DispatchQueue.main.async {
                    
                    self?.countLbl.text = "\(i)"

                }
                
            }
            
        }
    }
}


extension ViewController{
    
    func T1(){
        
        for i in 1...100{
            
            print("T1.. \(i)")
            
        }
    }
    
    func T2(){
        
        for i in 100...500{
            
            print("T2 T2 ..\(i)")

        }
    }
    func T3(){
        
        for i in 500...1000{
            
            print("T3 T3 T3 ..\(i)")

        }
    }
    
    fileprivate func mySerialQueue() {
        // Do any additional setup after loading the view.
        
        
        //dispatch queus by defaluts run on seriel queus and seriel queus run on main thread
        
        
        // customCreate Serial queue with name
        
        let myserialQueue = DispatchQueue(label: "myserialQueue")
        
        myserialQueue.sync { [weak self] in
            
            self?.T1()
            self?.T2()
            self?.T3()
        }
    }
    
    fileprivate func myConcurentQueue() {
        //cuncurency is excute parller <---> also know global queue
        
        let myqueus = DispatchQueue.global()
        
        myqueus.async { [weak self] in
            self?.T1()
        }
        
        myqueus.async { [weak self] in
            self?.T2()
        }
        myqueus.async { [weak self] in
            self?.T3()
        }
    }
    
}
