//
//  ContentView.swift
//  OperationQueueExp
//
//  Created by Raghu on 06/05/24.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var ViewModel = ContentViewModel()
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
            
            Button(action: {
                
                print("printed")
            }, label: {
                Text("Next")
                    .frame(width: 150,height: 60)
                    .foregroundColor(.red)
                
                
            })
        }
        .padding()
        .onAppear{
            
            ViewModel.testOperation()
            
            ViewModel.createThred()
        }
    }
}

#Preview {
    ContentView()
}

class ContentViewModel:ObservableObject{
    
    func testOperation(){
        
        print("operation started")
        
      //  blockFunction()
        
        
        let queue = OperationQueue()
        //serial queue
        //queue.maxConcurrentOperationCount = 1
       // op2.addDependency(op3)
       // queue.qualityOfService = .background
        

        queue.addOperations([op1,op2,op3], waitUntilFinished: false)
        print("operation ended")

    }
    
   fileprivate var op1 = BlockOperation{
       
        for i in 0...100{

            print(i)
        }

       sleep(2)
    }
    let op2 = BlockOperation{
       
        for i in 100...150{

            print(i)
        }
        sleep(2)

    }
    let op3 = BlockOperation{
       
        for i in 150...200{

            print(i)
        }

        sleep(2)

    }
    
    
    private func blockFunction(){
        
        let op1 = BlockOperation()
        op1.addExecutionBlock {
            print("please")
            
            for i in 0...10{

                print(i)
            }
            
        }
        let op2 = BlockOperation()

        op2.addExecutionBlock {
            print("Subscribe")
            for i in 10...20{

                print(i)
            }
        }
        let op3 = BlockOperation()

        op3.addExecutionBlock {
            print("to")
           
        }
       // op.start()
        
//        let opQueue = OperationQueue()
//        
//        opQueue.qualityOfService = .background
//        opQueue.addOperation(op1)
//        op1.addDependency(op2)
//        opQueue.addOperation(op2)

        
    }
    
  
    
    //Constom create thered
    
    
    func createThred(){
        
        let thread:Thread = Thread(target: self, selector: #selector(thredSelector), object: nil)
        thread.start()
      
    }
    
    @objc func thredSelector(){
        
        print("custom thread")
    }
    
}
