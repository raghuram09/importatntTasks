//
//  OperationQueueExpApp.swift
//  OperationQueueExp
//
//  Created by Raghu on 06/05/24.
//

import SwiftUI

@main
struct OperationQueueExpApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
