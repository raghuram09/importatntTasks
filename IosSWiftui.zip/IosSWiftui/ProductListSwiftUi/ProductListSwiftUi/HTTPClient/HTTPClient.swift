//
//  HTTPClient.swift
//  ProductListSwiftUi
//
//  Created by Apple on 07/01/24.
//

import Foundation

enum NetworkError:Error{
    
    case invalidUrl
    case invalidResponce
}

final class ApiManager{
    
    func GetData<T: Decodable>(url:String) async throws -> T{
        
        guard let url = URL(string: url) else {
            throw NetworkError.invalidUrl
        }
        let (data, responce) = try await URLSession.shared.data(from: url)
        
        guard (responce as? HTTPURLResponse)?.statusCode == 200 else{
            
            throw NetworkError.invalidResponce
        }
        return try JSONDecoder().decode(T.self, from: data)
      
    }
    
}
