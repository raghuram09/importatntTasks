//
//  ProductListSwiftUiApp.swift
//  ProductListSwiftUi
//
//  Created by Apple on 07/01/24.
//

import SwiftUI

@main
struct ProductListSwiftUiApp: App {
    var body: some Scene {
        WindowGroup {
            ProductsView()
        }
    }
}
