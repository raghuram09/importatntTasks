//
//  ProductViewModel.swift
//  ProductListSwiftUi
//
//  Created by Apple on 07/01/24.
//

import Foundation

@MainActor class ProductViewModel:ObservableObject{
    
    @Published var products: [Product] = []
    private let manager = ApiManager()
    
    func fetchProducts() async{
        
        do {
            
            products = try await manager.GetData(url: "https://fakestoreapi.com/products")
            
            print(products)
            
            
            
        }catch{
            
            
        }
    }
}
