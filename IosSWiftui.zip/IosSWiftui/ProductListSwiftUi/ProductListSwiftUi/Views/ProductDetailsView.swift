//
//  ProductDetailsView.swift
//  ProductListSwiftUi
//
//  Created by Apple on 08/01/24.
//

import SwiftUI

struct ProductDetailsView: View {
    
    let product : Product
    var body: some View {

        VStack{
            
            if let url = URL(string: product.image ?? ""){
                AsyncImage(url: url) { image in
                    image
                        .resizable()
                        .scaledToFit()
                } placeholder: {
                    ProgressView()
                }
                .frame(height: 300)
            }
            Text(product.title ?? "")
                .font(.headline)
            Text(product.description ?? "")
                .foregroundStyle(.secondary)
                .padding()
            
            HStack{
                
                HStack{
                    
                    Image(systemName: "star.fill")
                        .foregroundStyle(.yellow)
                    Text(((product.rating.rate?.toString() ?? "") + " " + "Rating"))
                        .foregroundStyle(.secondary)
                }
                .font(.callout)
                
                Spacer()
                
                circleImage
                Text("4.6 Riviews")
                
                Spacer()
                
                circleImage
                
                Text("4.6k Sold")
                
            }
            .foregroundStyle(.secondary)
            .font(.callout)
            
            Spacer()

        }
        .padding()


    }
    
    var circleImage: some View{
        
        Image(systemName: "circle.fill")
            .resizable()
            .frame(width: 8,height: 8)
    }
}

struct ProductDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        ProductDetailsView(product: Product.dummy)
    }
}
