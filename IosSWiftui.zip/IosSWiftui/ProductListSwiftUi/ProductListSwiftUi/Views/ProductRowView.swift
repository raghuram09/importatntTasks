//
//  ProductRowView.swift
//  ProductListSwiftUi
//
//  Created by Apple on 08/01/24.
//

import SwiftUI

struct ProductRowView: View {
    
    let product:Product
    
    var body: some View {
        HStack{
            if let url = URL(string: product.image ?? ""){
                
                productImage(url: url)


            }
          
            VStack(alignment: .leading,spacing: 10){
                
                Text(product.title ?? "")
                    .font(.headline)
                
                //category & rating
                
                HStack(spacing: 20){
                    
                    Text(product.category ?? "")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    
                    HStack{
                        
                        Image(systemName: "star.fill")
                           
                        Text(product.rating.rate?.toString() ?? "")
                            
                    }
                    .fontWeight(.medium)
                    .foregroundColor(.orange)
                }
                //Description
                Text(product.description ?? "")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .lineLimit(3)
                
                HStack{
                    
                    Text( "$" + (product.price?.currencyFormat() ?? "") )
                        .font(.title3)
                        .foregroundStyle(.indigo)
                    Spacer()
                    Button {
                        
                        
                        
                    } label: {
                        
                        Text("Buy")
                            .background(.indigo)
                            .frame(minWidth:60)
                            .foregroundStyle(.white)
                            .cornerRadius(20)
                           
                    }

                    

                    
                }
                
            }
        }
        .padding()
        
    }
    
    func productImage(url: URL) -> some View {
        AsyncImage(url: url) { image in
            image.resizable()
                .scaledToFit()
        } placeholder: {
            ProgressView()
        }
        .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
    }
}

struct ProductRowView_Previews: PreviewProvider {
    static var previews: some View {
        ProductRowView(product: Product.dummy)
    }
}
