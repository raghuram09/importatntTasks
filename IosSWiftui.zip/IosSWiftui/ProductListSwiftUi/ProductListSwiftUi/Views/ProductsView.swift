//
//  ProductsView.swift
//  ProductListSwiftUi
//
//  Created by Apple on 07/01/24.
//

import SwiftUI

enum SortDirection {

    case asc
    case desc
}

struct ProductsView: View {
    
    @StateObject var viewModel = ProductViewModel()
    
    @State var search:String = ""
    
    @State private var filteredProducts:[Product] = []
    
    @State private var sortDirection:SortDirection = .asc
    private var finalproducts:[Product]{
        
        filteredProducts.isEmpty ?viewModel.products : filteredProducts
    }
    
    private func performSearch(keyword:String){
        
        filteredProducts = viewModel.products.filter { product in
            
            product.title!.contains(keyword)
            
        }
    }
    
    var sortDirectionText :String{
        
        sortDirection == .asc ? "sort Assending" : "sort Descending"
    }
    
    var body: some View {
        
        NavigationStack{
            
            Button {
                
                sortDirection = sortDirection == .asc ? .desc : .asc
                
            } label: {
                Text(sortDirectionText)
            }

            
            List(finalproducts){ product in
                
                NavigationLink {
                    
                    ProductDetailsView(product: product)
                } label: {
                    
                    ProductRowView(product:product)
                }
                
            }
            .navigationTitle("Products")
            
        }
        .searchable(text: $search )
        .onChange(of: search, perform: performSearch)
        
        .task {
            
            await viewModel.fetchProducts()
        }
    }
}

struct ProductsView_Previews: PreviewProvider {
    static var previews: some View {
        ProductsView()
    }
}
