//
//  ContentView.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var router:Router
    var body: some View {
       ProfileView()
    }
}

#Preview {
    ContentView()
}
