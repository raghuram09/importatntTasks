//
//  EditButton.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import SwiftUI

struct EditButton: View {
    var body: some View {
        HStack{
            
            ZStack{
                RoundedRectangle(cornerRadius: 24,style: .circular)
                    .fill(.white)
                    .shadow(radius: 5)
                Text("Edit Profile")
                    .font(.subheadline)
                    .bold()
                    .frame(width: 140,height: 32)
                  
                
            }
            .buttonStyle(.bordered)
            .frame(width: 140,height: 40)
        }
    }
}

#Preview {
    EditButton()
}
