//
//  FollwCountView.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import SwiftUI

struct FollwCountView: View {
    
    var followers: [User]
    var following: [User]
    
    @EnvironmentObject private var router:Router


    var body: some View {
        HStack{
            
            Spacer()
                VStack{
                    
                    Text("\(followers.count)")
                    Text("Followers")
                        .onTapGesture {
                            router.pushView(route: .followers)
                        }
                        
                    
                }
                .bold()
                .foregroundColor(.black)
            
            Spacer()
            
                VStack{
                    
                    Text("\(following.count)")
                    Text("Followers")
                    
                }
                .bold()
                .foregroundColor(.black)
            
            
            Spacer()
            
        }

    }
}

#Preview {
    FollwCountView(followers: User.allUsers, following: User.allUsers)
}
