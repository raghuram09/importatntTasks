//
//  HeaderView.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import SwiftUI

struct HeaderView: View {
    var user:User
    var body: some View {
       
        HStack{
            Image(systemName: "person")
                .foregroundColor(.purple)
                .frame(width: 80,height: 80)
                .font(.system(size: 35))
                .overlay(RoundedRectangle(cornerRadius: 40).stroke(Color.purple,lineWidth: 2))
            VStack{
                
                Text(user.displayName)
                    .bold()
                
                Text(user.userName)
                    .foregroundColor(.gray)
                
            }
            .padding(.leading,5)
            Spacer()
        }
        .padding(.horizontal)
    }
}

#Preview {
    HeaderView(user: User(id: "ram.anekalla@gmail", displayName: "RaghuRam", userName: "Ram"))
}
