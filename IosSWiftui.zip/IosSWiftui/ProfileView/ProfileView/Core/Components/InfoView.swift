//
//  InfoView.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import SwiftUI

struct InfoView: View {
    var body: some View {
        
        HStack{
            
            VStack(alignment: .leading, spacing: 10){
                
                Label("last Played",systemImage: "clock")
                                    
                    .foregroundColor(.gray)

                Label("Crypto.com Arena",systemImage: "map")
                    .foregroundColor(.gray)
                


                
            }
            Spacer()
        }
        .padding(.horizontal)
    }
}

#Preview {
    InfoView()
}
