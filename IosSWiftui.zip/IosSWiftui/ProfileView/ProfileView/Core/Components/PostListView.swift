//
//  PostListView.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import SwiftUI

struct PostListView: View {
    var body: some View {
   
            
            List{
                
                ForEach (0...10,id: \.self){ item in
                    
                    RowView()
                }
            }
            .listStyle(.plain)
        
    }
}

#Preview {
    PostListView()
}
