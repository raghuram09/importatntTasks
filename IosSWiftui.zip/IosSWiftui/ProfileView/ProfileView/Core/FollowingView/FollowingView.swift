//
//  FollowingView.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import SwiftUI

struct FollowingView: View {
    var following:[User]
    @EnvironmentObject private var router:Router

    var body: some View {
        VStack(alignment: .leading,spacing: 10){
            Button(action: {
                
                router.popToRootView()
            }, label: {
                Text("Back")
                   
            })
            .padding(.leading,10)
            Spacer()
            List{
                
                ForEach(following,id: \.self){ rowItem in
                    
                    Text(rowItem.userName)
                }
            }
        }
    }
}

#Preview {
    FollowingView(following: User.allUsers)
}
