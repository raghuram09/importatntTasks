//
//  ProfileView.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import SwiftUI

struct ProfileView: View {
    
    var body: some View {
            VStack(spacing: 10){
                
                HeaderView(user: User.mockUser)
                InfoView()
                FollwCountView(followers: User.allUsers, following: User.allUsers)
                EditButton()
                PostListView()
            }
        }
      
    }


#Preview {
    ProfileView()
}
