//
//  UserModel.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import Foundation

struct User:Identifiable,Hashable{
    
    var id:String
    var displayName:String
    var userName:String
    
    var followers:[User] = [User]()
    var following:[User] = [User]()
    
    static var emptyUser = User(id: "", displayName: "", userName: "")
    static var mockUser = User(id: "ram.anekalla@gmail.com", displayName: "Raghuram", userName: "Ram")
    
    static var allUsers = [User(id: "ram.anekalla@gmail.com", displayName: "Raghuram", userName: "Ram"),
                           User(id: "sara@gmail.com", displayName: "Sara Reddy", userName: "gaganaSri"),
                           User(id: "sandhya@gmail.com", displayName: "Sandhya", userName: "Sandhya")]



}
