//
//  ProfileViewApp.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import SwiftUI

@main
struct ProfileViewApp: App {
    var body: some Scene {
        WindowGroup {
            AppContainerView()
        }
    }
}
