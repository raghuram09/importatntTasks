//
//  AppContainerView.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import SwiftUI

struct AppContainerView: View {
    @ObservedObject var router = Router()
    var body: some View {
        NavigationStack(path: $router.navigationPath) {
              ContentView()
                .navigationDestination(for: Route.self) { route in
                    
                    
                    switch route{
                        
                    case .ContentView:
                        ContentView()
                        
                    case .followers:
                        FollowingView(following: User.allUsers)
                            .navigationBarBackButtonHidden()
                        
                    case .following:
                        FollowingView(following: User.allUsers)
                            .navigationBarBackButtonHidden()
                    }
                }
        }
        .environmentObject(router)
        
    }
}

