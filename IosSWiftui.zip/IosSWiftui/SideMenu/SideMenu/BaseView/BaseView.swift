//
//  BaseView.swift
//  SideMenu
//
//  Created by Raghu on 27/03/24.
//

import SwiftUI

struct BaseView: View {
    @State var isOpenSideMenu: Bool = false
    @State var text = ""
    var body: some View {
        ZStack{
            NavigationView {
                    Text(text)
                    .navigationBarItems(leading: (
                        Button(action: {
                            self.isOpenSideMenu.toggle()
                        }) {
                            Image(systemName: "line.horizontal.3")
                                .imageScale(.large)
                    }))
            }

            SideMenuView(isOpen: $isOpenSideMenu, text: $text)
                .edgesIgnoringSafeArea(.all)
        }    }
}

#Preview {
    BaseView()
}
