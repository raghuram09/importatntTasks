//
//  ContentView.swift
//  SideMenu
//
//  Created by Raghu on 26/03/24.
//

import SwiftUI

struct ContentView: View {
  
    var body: some View {
     
            BaseView()
    
    }
}
#Preview {
    ContentView()
}


