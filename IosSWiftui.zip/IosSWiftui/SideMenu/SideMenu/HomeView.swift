//
//  HomeView.swift
//  SideMenu
//
//  Created by Raghu on 27/03/24.
//

import SwiftUI

struct HomeView: View {

    var body: some View {
        VStack{
            
            Text("raghu")
        }
    }
}

#Preview {
    HomeView()
}
