//
//  AppContainer.swift
//  SideMenu
//
//  Created by Raghu on 27/03/24.
//

import SwiftUI

struct AppContainerView: View {
    @ObservedObject var router = Router()
    var body: some View {
        NavigationStack(path: $router.navigationPath) {
              ContentView()
                .navigationDestination(for: Route.self) { route in
                    
                    
                    switch route{
                        
                    case .ContentView:
                        ContentView()
                        
                    case .HomeV:
                      HomeView()
                            .navigationBarBackButtonHidden()
                        
                    case .following:
                        HomeView()
                        .navigationBarBackButtonHidden()
                    }
                }
        }
        .environmentObject(router)
        
    }
}

