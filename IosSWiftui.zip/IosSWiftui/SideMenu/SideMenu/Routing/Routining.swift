//
//  Routining.swift
//  SideMenu
//
//  Created by Raghu on 27/03/24.
//

import Foundation


import Foundation
import SwiftUI
enum Route:Hashable{
    case ContentView
    case HomeV
    case following
    
}


final class Router:ObservableObject{
    
    @Published var navigationPath = NavigationPath()
    
    func pushView(route:Route){
        
        navigationPath.append(route)
    }
    
    func popToRootView(){
        
        navigationPath = .init()
    }
    
    func popToSpecificView(k:Int){
        
        navigationPath.removeLast(k)
    }
}
