//
//  SideMenuApp.swift
//  SideMenu
//
//  Created by Raghu on 26/03/24.
//

import SwiftUI

@main
struct SideMenuApp: App {
    var body: some Scene {
        WindowGroup {
            AppContainerView()
        }
    }
}
