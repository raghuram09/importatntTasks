//
//  Images.swift
//  SideMenuDemo
//
//  Created by Raghu on 30/04/24.
//

import Foundation
import SwiftUI
enum ImageName: String {
    case splash, splashLogo, facebook, google, lock, message, profile, backIcon, payoneer, paypal, visa,primeData
    case onboarding1 = "onboarding-1"
    case onboarding2 = "onboarding-2"
    
    case person = "person.fill"
    case eye = "eye"
    case eyeSlash = "eye.slash"
    case checkMarkFilled = "checkmark.circle.fill"
    case checkmark = "checkmark.circle"
}

extension Image {
    init(name: ImageName) {
        self.init(name.rawValue)
    }
    
    init(sysNameImage: ImageName) {
        self.init(systemName: sysNameImage.rawValue)
    }
}
