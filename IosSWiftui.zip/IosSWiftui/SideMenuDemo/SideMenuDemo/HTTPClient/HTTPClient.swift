//
//  HTTPClient.swift
//  SideMenuDemo
//
//  Created by Raghu on 01/04/24.
//

import Foundation
import Alamofire

enum networkError:Error{
    
    case invalidUrl
    case noResponce
    case noData
}


protocol NetworkManagerDelegate{
    
    func getProducts(completion:@escaping(Result<[Product],CustomError>) ->Void)
    func getSchoolsList(completion:@escaping(Result<[schoolsModel],networkError>) -> Void)

}

class AlamofireNetworkManager:NetworkManagerDelegate{
    
    func getProducts(completion:@escaping(Result<[Product],CustomError>) ->Void){
        
        AF.request("https://fakestoreapi.com/products",method: .get).response { responce in
            
            guard let data = responce.data,
                  let list = try? JSONDecoder().decode([Product].self, from: data) else{
                
                return completion(.failure(.genericError))
                
            }
            completion(.success(list))
            
        }
    }
    
    
    func getSchoolsList(completion:@escaping(Result<[schoolsModel],networkError>) -> Void){
        
        guard let schoolsUrl = URL.SchoolsUrl() else{
            
            return completion(.failure(.invalidUrl))
        }
        
                var request = URLRequest(url: schoolsUrl)
                request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request){ data , responce , error in
            print(".............")
            guard let data = data, error == nil else{
                
                return completion(.failure(.noData))
            }
            
            do {
                let schoolsList =  try JSONDecoder().decode([schoolsModel].self,from: data)
                
                print(schoolsList)
                completion(.success(schoolsList))
            }catch{
                
                completion(.failure(.noResponce))
            }
        }.resume()
    }
    
    
}

protocol HTTPClientManagerDelegate{
    
    func getProducts<T:Decodable>(url:String,methodType:HTTPMethod,completion:@escaping(Result<T,CustomError>) ->Void)

}


class NetworkManager:HTTPClientManagerDelegate{
    
    func getProducts<T:Decodable>(url:String,methodType:HTTPMethod,completion:@escaping(Result<T,CustomError>) ->Void){
        
        AF.request(url,method: .get).response { responce in
            
            guard let data = responce.data,
                  let list = try? JSONDecoder().decode(T.self.self, from: data) else{
                
                return completion(.failure(.genericError))
                
            }
            completion(.success(list))
            
        }
    }
}
