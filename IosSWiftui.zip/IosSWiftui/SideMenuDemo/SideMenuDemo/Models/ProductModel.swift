//
//  ProductModel.swift
//  SideMenuDemo
//
//  Created by Raghu on 01/04/24.
//

import Foundation

struct Product: Codable,Hashable,Identifiable{
    
    let id: Int?
    let title: String?
    let price:Float
    let description:String?
    let category:String
    let image:String?
    let rating:Rate
    
}

struct Rate:Codable,Hashable{
    
    let rate:Float
    let count:Int
}
