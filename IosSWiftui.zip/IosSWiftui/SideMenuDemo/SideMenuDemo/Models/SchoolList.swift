//
//  SchoolList.swift
//  SideMenuDemo
//
//  Created by Raghu on 07/04/24.
//

import Foundation

typealias codebale = Decodable & Encodable

struct schoolsModel:codebale,Hashable{
    
    var dbn:String?
    var school_name:String?
    var school_email:String?
    
    enum CodingKeys: String, CodingKey {
       
        case dbn = "dbn"
        case school_name = "school_name"
    }
}
