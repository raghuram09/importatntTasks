//
//  AppContainerView.swift
//  ProfileView
//
//  Created by Raghu on 24/03/24.
//

import SwiftUI

struct AppContainerView: View {
    @ObservedObject var router = Router()
    var LoginReponce = "LoginSuccess"
    var body: some View {
        NavigationStack(path: $router.navigationPath) {
            
           
            
                LoginView()
            
                .navigationDestination(for: Route.self) { route in
                    
                    
                    switch route{
                        
                    case .LoginView:
                    
                        LoginView()
                        
                    case .SignUp:
                        
                        SignUpView()
                        
                    case .DashBoard:
                       DashBoardView()
                            .navigationBarBackButtonHidden(true)
                    }
                }
        }
        .environmentObject(router)
        
    }
}

