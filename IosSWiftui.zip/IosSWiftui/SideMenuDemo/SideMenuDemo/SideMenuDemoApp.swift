//
//  SideMenuDemoApp.swift
//  SideMenuDemo
//
//  Created by Raghu on 31/03/24.
//

import SwiftUI

@main
struct SideMenuDemoApp: App {
    var body: some Scene {
        WindowGroup {
            AppContainerView()
        }
    }
}
