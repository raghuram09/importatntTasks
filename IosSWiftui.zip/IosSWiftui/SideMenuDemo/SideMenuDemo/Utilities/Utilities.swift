//
//  Utilities.swift
//  SideMenuDemo
//
//  Created by Raghu on 05/05/24.
//

import Foundation

class UserDefaultsManager {
    static let shared = UserDefaultsManager() // Singleton instance
    
    private init() {} // Private initializer to prevent external instantiation
    
    func saveData(_ value: Any?, forKey key: String) {
        UserDefaults.standard.set(value, forKey: key)
    }
    
    func retrieveData(forKey key: String) -> Any? {
        return UserDefaults.standard.value(forKey: key)
    }
}
