//
//  ProductViewModel.swift
//  SideMenuDemo
//
//  Created by Raghu on 01/04/24.
//

import Foundation
import Alamofire

enum CustomError:Error{
    
    case genericError
    case UrlError
}
struct UserDisplay:Identifiable{
    
    var name:String
    var id: Int
}
class ProductViewModel:ObservableObject{
    
    
    //using dependency injection we can achive the networkmanger function here
    
    private let networkManger : UserRepositoryDelegate
    private let httpManger:HTTPClientManagerDelegate
    
    init(networkManger:UserRepositoryDelegate = UserRepository(),httpManger:HTTPClientManagerDelegate = NetworkManager()){
        
        self.networkManger = networkManger
        self.httpManger = httpManger
    }
    
    @Published var products = [Product]()
    
    @Published var users = [UserDisplay]()
    
    func getData(){
        
        networkManger.getProducts { result in
            
            switch result{
                
            case .success(let success):
                
                self.products = success
            case .failure(let failure):
                
                print(failure.localizedDescription)
            }
        }
        
    }
    
    private func createUsers(responceArray :[Product]){
        
        var localUsers = [UserDisplay]()
        
        for item in responceArray{
            
            localUsers.append(UserDisplay(name: item.title ?? "", id: item.id ?? 0))
        }
        users = localUsers
    }
}
