//
//  SchoolListViewModel.swift
//  SideMenuDemo
//
//  Created by Raghu on 07/04/24.
//

import Foundation

class SchoolListViewModel:ObservableObject{
    
    @Published var schoolsList = [schoolsModel]()

    private let networkManger : UserRepositoryDelegate

    init(networkManger:UserRepositoryDelegate = UserRepository()){
        
        self.networkManger = networkManger

    }
   
    func getschoolsList(){
        
        networkManger.getSchoolsList { responce in
            
            
            switch responce{
                
            case .success(let schoolsListRes):
                
                DispatchQueue.main.async {
                    self.schoolsList = schoolsListRes
                    
                    print(self.schoolsList)
                }
             
                
            case .failure(let error):
                
                print(error.localizedDescription)
            }
        }
        
    }
    
}
