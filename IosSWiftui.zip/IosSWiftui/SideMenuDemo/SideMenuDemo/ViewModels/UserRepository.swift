//
//  UserRepository.swift
//  SideMenuDemo
//
//  Created by Raghu on 01/04/24.
//

import Foundation

import Alamofire
protocol UserRepositoryDelegate{
    
    func getProducts(completion:@escaping(Result<[Product],CustomError>) ->Void)
    func getSchoolsList(completion:@escaping(Result<[schoolsModel],networkError>) -> Void)

}

class UserRepository : UserRepositoryDelegate{
  
    
    private let networkManager : NetworkManagerDelegate
    init (networkManager : NetworkManagerDelegate = AlamofireNetworkManager()){
        
        self.networkManager = networkManager
    }
    
    func getProducts(completion: @escaping (Result<[Product], CustomError>) -> Void) {
        
        networkManager.getProducts(completion: completion)
    }
    
    func getSchoolsList(completion: @escaping (Result<[schoolsModel], networkError>) -> Void) {
        
        networkManager.getSchoolsList(completion: completion)
    }
    
    
}

