//
//  ContentView.swift
//  SideMenuDemo
//
//  Created by Raghu on 31/03/24.
//

import SwiftUI

struct DashBoardView: View {
    
    @State var isPresented = false
    @State var selectedTab = SideMenuOption.home

    var body: some View {
        
        SideMenuContentView($isPresented) {
            
            switch selectedTab {
            case .home:
                HomeView()
                
            case .cart:
                
                CartView()
                
            case .settings:
                
                SettingsView()

            case .products:
                ProductView(Vm: ProductViewModel())
            }
        }
        .overlay(alignment: .leading){
            
            SideMenu($isPresented){
                SideMenuView($selectedTab, isPresented: $isPresented)
            }
        }
    }
}

#Preview {
    DashBoardView()
}
