//
//  HomeRowView.swift
//  SideMenuDemo
//
//  Created by Raghu on 08/05/24.
//

import SwiftUI

struct HomeRowView: View {
    var rowData:schoolsModel
    var body: some View {
        
        VStack(alignment: .leading){
            
            Text(rowData.school_name ?? "")
            Text(rowData.dbn ?? "")
        }
        .foregroundColor(Color.white)
        .bold()
        .padding()
        .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
        .background {
            LinearGradient(
                stops: [
                    Gradient.Stop(color: .blue, location: 0.0),
                    Gradient.Stop(color: .purple, location: 1.0)
                ],
                startPoint: UnitPoint(x: 0, y: 0),
                endPoint: UnitPoint(x: 1, y: 1)
            )
        }
        .cornerRadius(20)
        
    }
}

#Preview {
    HomeRowView(rowData: schoolsModel())
}
