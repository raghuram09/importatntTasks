//
//  HomeView.swift
//  SideMenuDemo
//
//  Created by Raghu on 31/03/24.
//

import SwiftUI

struct HomeView: View {
    
    @StateObject var Vm = SchoolListViewModel()

    @State var search:String = ""
    
    @State private var filteredProducts:[schoolsModel] = []
    
    private var finalproducts:[schoolsModel]{
        
        filteredProducts.isEmpty ?Vm.schoolsList : filteredProducts
    }

    var body: some View {
        ZStack{
            VStack(spacing: 30){
                List{
                    ForEach(finalproducts,id: \.self){ item in
                        
                     HomeRowView(rowData: item)
                    }
                    .onDelete(perform: deleteItem)
                }
                .listStyle(.plain)
            }
            
        }
        .onAppear{
            
            Vm.getschoolsList()
        }
        
//        .searchable(text: $search )
//        .onChange(of: search) {
//            performSearch(keyword: search)
//        }

       
    }
    private func deleteItem(at offsets: IndexSet) {
    
        Vm.schoolsList.remove(atOffsets: offsets)

    }
    
    private func performSearch(keyword:String){
        
        filteredProducts = Vm.schoolsList.filter { schoolData in
            
            schoolData.school_name!.contains(keyword)
            
            
        }
        print(filteredProducts.count)
        
    }
}

#Preview {
    HomeView()
}
