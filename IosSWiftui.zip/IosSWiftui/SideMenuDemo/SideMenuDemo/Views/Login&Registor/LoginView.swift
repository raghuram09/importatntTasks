//
//  LoginView.swift
//  SideMenuDemo
//
//  Created by Raghu on 30/04/24.
//

import SwiftUI

struct LoginView: View {
    @ObservedObject private var viewModel = LoginViewModel()
    @EnvironmentObject private var router:Router

    @State private var isLoggedIn: Bool = false

    var body: some View {
        ZStack{
            Image(name: .splash)
                .ignoresSafeArea()
            
            ScrollView{
                Image(name: .primeData)
                    .resizable()
                    .frame(width: 200, height: 200)
                     .padding(.top,20)
                     .cornerRadius(50)
                
                Text("Login To Your Prime Data Soft Account")
                    .font(.system(size: 15, weight: .bold))
                    .padding(.top, 20)
                    .foregroundStyle(.blue.gradient)
                VStack{
                    CostomTextField(placeholder: "Email", text: $viewModel.email)
                        .padding(.top, 20)
                    
                    CostomTextField(placeholder: "Password", text: $viewModel.password, isPasswordField: true)
                        .padding(.top)
                }
                .padding()
                Text("Or Continue With")
                    .font(.system(size: 12, weight: .bold))
                    .padding(.top,5)
                
                HStack {
                    Image(name: .facebook)
                        .resizable()
                        .scaledToFit()
                    
                    Image(name: .google)
                        .resizable()
                        .scaledToFit()
                }
                .padding(.top,5)
                
                Button {
                    print("Forgot password is tapped.")
                } label: {
                    Text("Forgot Your Password?")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(.lightGreen)
                }

                let config = CustomButtonConfig(title: "Login") {
                    
                    print("LOGIN CODE")
                    router.pushView(route: .DashBoard)
                    UserDefaultsManager.shared.saveData("LoginSuccess", forKey: "isLoggedIn")

                }
                
                CustomButton(config: config)
                    .frame(width: UIScreen.main.bounds.width - 200)
                    .padding(.top)
                    
                HStack(spacing: 5){
                    Text("Don't have an account")

                    Button {
                        router.pushView(route: .SignUp)
                        

                    } label: {
                        Text("Signup")
                            .font(.system(size: 15, weight: .medium))
                            .foregroundColor(.lightGreen)
                    }
                  
                }  .padding(.top,10)
               
                
            }
        }
    }
}

#Preview {
    LoginView()
}
