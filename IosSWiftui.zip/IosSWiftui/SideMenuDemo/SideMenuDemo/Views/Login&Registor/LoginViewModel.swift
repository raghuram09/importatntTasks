//
//  LoginViewModel.swift
//  SideMenuDemo
//
//  Created by Raghu on 30/04/24.
//

import Foundation

final class LoginViewModel: ObservableObject {
    @Published var email: String = ""
    @Published var password: String = ""
}
