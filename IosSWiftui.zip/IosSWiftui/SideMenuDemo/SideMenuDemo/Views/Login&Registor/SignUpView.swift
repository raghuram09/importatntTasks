//
//  SignUpView.swift
//  SideMenuDemo
//
//  Created by Raghu on 03/05/24.
//

import SwiftUI

struct SignUpView: View {
    @ObservedObject private var viewModel = SignUpViewModel()
    @EnvironmentObject private var router:Router

    var body: some View {
        ZStack{
            
            Image(name: .splash)
                .ignoresSafeArea()
            
            ScrollView{
                
              
                
                Text("Sign Up For Free")
                    .font(.system(size: 20, weight: .bold))
                    .padding(.top, 100)
                
                CostomTextField(placeholder: "Enter Your First Name", text: $viewModel.firstName, leftImage: .none)
                    .padding(.top, 30)
                
                CostomTextField(placeholder: "Enter Your Last Name", text: $viewModel.lastName, leftImage: .none)
               
                CostomTextField(placeholder: "Enter Your  email", text: $viewModel.email, leftImage: .none)
                
                CostomTextField(placeholder: "Enter Your number", text: $viewModel.mobileNumber, leftImage: .none)
                
                CostomTextField(placeholder: "Enter Your Department", text: $viewModel.department, leftImage: .none)
                CostomTextField(placeholder: "Enter Your location", text: $viewModel.Location, leftImage: .none)

                let config = CustomButtonConfig(title: "Next") {

                    router.popToRootView()
                }
                CustomButton(config: config)
                    .padding(.bottom)
                    .frame(width: 150)
                    .padding(.top, 30)
            }
            }
            .padding()
        }
        
    }

#Preview {
    SignUpView()
}
