//
//  SignUpViewModel.swift
//  SideMenuDemo
//
//  Created by Raghu on 03/05/24.
//

import Foundation

final class SignUpViewModel: ObservableObject {
    @Published var firstName: String = ""
    @Published var lastName: String = ""
    @Published var email: String = ""
    @Published var mobileNumber: String = ""
    @Published var department: String = ""
    @Published var Location: String = ""
}
