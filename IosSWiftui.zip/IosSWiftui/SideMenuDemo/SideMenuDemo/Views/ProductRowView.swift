//
//  ProductRowView.swift
//  SideMenuDemo
//
//  Created by Raghu on 23/04/24.
//

import SwiftUI

struct ProductRowView: View {
    
    var productdata:Product

    var body: some View {
    
        ZStack(alignment:.topTrailing){
            VStack(alignment: .leading,spacing: 5){
                Text(productdata.title ?? "")
                    .bold()
                    .lineLimit(2)
                
                Text("$ \(productdata.price)")
            }
            .padding()
            .background(.ultraThinMaterial)
            .cornerRadius(20)
        }
    }
}

#Preview {
    ProductRowView(productdata: Product(id: 1, title: "raghu", price: 20.5, description: "hello", category: "cloths", image: "gfhfahs", rating: Rate(rate: 10.5, count: 2)))
}
