//
//  ProductView.swift
//  SideMenuDemo
//
//  Created by Raghu on 01/04/24.
//

import SwiftUI

struct ProductView: View {
    
    @StateObject var Vm = ProductViewModel()
    @State var search:String = ""

    let colums : [GridItem] = [
        GridItem(.flexible(),spacing: nil,alignment: nil),
        GridItem(.flexible(),spacing: nil,alignment: nil),
        GridItem(.flexible(),spacing: nil,alignment: nil)
    ]
    var body: some View {
        
        ScrollView{
            
            LazyVGrid(columns: colums){
                
                ForEach(Vm.products,id: \.self){ item in
                    
                   
                    ProductRowView(productdata: item)

                }
            }
            .padding(20)

        }

        .onAppear{
            
            Vm.getData()
        }
        

    }
       

}

#Preview {
    ProductView()
}
