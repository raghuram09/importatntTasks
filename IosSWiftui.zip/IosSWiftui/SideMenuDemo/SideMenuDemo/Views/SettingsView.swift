//
//  SettingsView.swift
//  SideMenuDemo
//
//  Created by Raghu on 31/03/24.
//

import SwiftUI

struct SettingsView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SettingsView()
}
