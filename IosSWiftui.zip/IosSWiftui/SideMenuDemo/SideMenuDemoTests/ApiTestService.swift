//
//  ApiTestService.swift
//  SideMenuDemoTests
//
//  Created by Raghu on 07/04/24.
//

import Foundation
@testable import SideMenuDemo

var result: Result<[SideMenuDemo.Product], SideMenuDemo.CustomError>!
class MockApiTest:UserRepositoryDelegate{
    func getProducts(completion: @escaping (Result<[SideMenuDemo.Product], SideMenuDemo.CustomError>) -> Void) {
        
        completion(result)

    }
    
}
