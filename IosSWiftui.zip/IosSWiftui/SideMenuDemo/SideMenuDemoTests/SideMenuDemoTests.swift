//
//  SideMenuDemoTests.swift
//  SideMenuDemoTests
//
//  Created by Raghu on 06/04/24.
//

import XCTest
@testable import SideMenuDemo

final class SideMenuDemoTests: XCTestCase {

    func test_Api_Failur(){
        
        var mockServivce = MockApiTest()
        var sut = ProductViewModel(networkManger: mockServivce)
        sut.getData()
        XCTAssert(sut.products.isEmpty)
    }

    func test_Api_Success(){
        
        var mockServivce = MockApiTest()
        var sut = ProductViewModel(networkManger: mockServivce)
        sut.getData()
        XCTAssert(sut.products.count == 500)
    }

}
