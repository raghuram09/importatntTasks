import UIKit

class LocationManager{
    
    static let shared = LocationManager()
    
     private init(){}
    
    func requestForLocation(){
        //Code Process
        print("Location granted")
    }
    
}


