//
//  HTTPClient.swift
//  SwiftMVVMRefApi
//
//  Created by Apple on 19/11/23.
//

import Foundation


class HTTPClient {
    
    static let shared = HTTPClient()
    
    private init(){
        
    }
    var extraHeaders:KeyValuePairs <String,String>? = nil
    func getRequest(url: URL, parms: Data, timeOutInterval: TimeInterval = 30) -> NSMutableURLRequest {
        let theRequest = NSMutableURLRequest(url: url,
                                             cachePolicy: .reloadIgnoringLocalCacheData,
                                             timeoutInterval: timeOutInterval)
        
        theRequest.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        theRequest.addValue("MTYIOS", forHTTPHeaderField: "User-Agent")//useragent type
        theRequest.httpMethod = "GET"
        theRequest.httpBody = parms
        return addExtraHeadersIfNeeded(request: theRequest)
    }
    func postRequest(url: URL, parms: Encodable, timeOutInterval: TimeInterval = 30) -> NSMutableURLRequest {
        let theRequest = NSMutableURLRequest(url: url,
                                             cachePolicy: .reloadIgnoringLocalCacheData,
                                             timeoutInterval: timeOutInterval)
        
        theRequest.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        theRequest.addValue("MTYIOS", forHTTPHeaderField: "User-Agent")//useragent type
        //theRequest.addValue("application/pdf", forHTTPHeaderField: "Accept") // download request

        theRequest.httpMethod = "GET"
        do {
            
            let jsonBody = try JSONEncoder().encode(parms)
            theRequest.httpBody = jsonBody

        } catch{
            
        }
        return addExtraHeadersIfNeeded(request: theRequest)
    }
    func addExtraHeadersIfNeeded(request: NSMutableURLRequest) -> NSMutableURLRequest {
        guard let moreHeaders = extraHeaders else {
            return request
        }
        for header in moreHeaders {
            request.addValue(header.value, forHTTPHeaderField: header.key)
        }
        return request
    }
    
    //addpamerters for params if need hear
    
    func callForPostApi<T:Codable>(urlString: String, modelType: T.Type, paramters: String, complesion:@escaping(Bool,Result<T, networkError>) -> Void) {
        
        guard let productUrl = URL.productURL() else{
            
            return complesion(false,.failure(.badUrl))
        }
        
        
        URLSession.shared.dataTask(with: postRequest(url: productUrl, parms:paramters ) as URLRequest) { data, responce, error in
            
            guard let data = data, error == nil else {
                return complesion(false,.failure(.noData))
            }
            //responcestatuscode check
            
            let statusCode = (responce as? HTTPURLResponse)?.statusCode
            
            if let statusCode1 = statusCode, 200...299 ~= statusCode1{
                
                //
                
            }
            
            do {
                let model = try JSONDecoder().decode(T.self, from: data)

                complesion(true,.success(model))
            }catch{
                
                 complesion(false,.failure(.message(error)))
            }
            
        }.resume()
        
    }
   }
