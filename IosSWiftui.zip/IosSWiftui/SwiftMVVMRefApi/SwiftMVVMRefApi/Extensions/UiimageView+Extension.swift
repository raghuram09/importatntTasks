//
//  UiimageView+Extension.swift
//  SwiftMVVMRefApi
//
//  Created by Apple on 13/11/23.
//

import Foundation
import Kingfisher


extension UIImageView{
    
    func setimage(with urlstring: String){
        
        guard let url = URL.init(string:urlstring)else{
            return
        }
        
        let resource = ImageResource(downloadURL: url,cacheKey: urlstring)
        kf.indicatorType = .activity
        kf.setImage(with: resource)
    }
    
}
