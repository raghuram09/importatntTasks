//
//  ProductViewModel.swift
//  SwiftMVVMRefApi
//
//  Created by Apple on 09/11/23.
//

import Foundation

protocol ProductViewModelPDelegate {
    
    func getProductsProtocol()
}

class ProductViewModel: ProductViewModelPDelegate{
    
    var vcDelegate:viewControllerDelegate?
    
    //var products:[Product] = []
    
   // var eventHandler: ((_ event:Event) ->Void)?  // data binding closure
    
        
    func getProductsProtocol(){
        
        //self.eventHandler?(.loading)
        ApiService.shared.getProductsData { responce in
            
            //self.eventHandler?(.stopLoading)

            switch responce{
                
                
            case .success(let products):
                
                
                self.vcDelegate?.successResponce(responce: products)
               // print(products)
               // self.products = products
                
               // self.eventHandler?(.dataLoaded)
                
            case.failure(let error):
                
                print(error)
               // self.eventHandler?(.error(error))
            }
            
        }
    }
}
extension ProductViewModel{
    
    enum Event{
        
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
    }
}
