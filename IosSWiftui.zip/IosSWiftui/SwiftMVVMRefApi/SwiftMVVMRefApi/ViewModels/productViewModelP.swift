//
//  productViewModelP.swift
//  SwiftMVVMRefApi
//
//  Created by Apple on 19/11/23.
//

import Foundation



//protocol ProductViewModelPDelegate {
//
//    func getProductsProtocol()
//}



class ProductViewModelP: ProductViewModelPDelegate {

   // var vcDelegate:viewControllerDelegate?
   // var VCPDelegate:VCPresenterDelegate?

    func getProductsProtocol() {

        print("getProductsProtocol ...")

        let parames = userProduct(id: 10, title: "raghu", price: 10.1)

//        let parames = ""

//        self.vcDelegate?.successResponce(responce: [Product]())
//
//        self.vcDelegate?.failureResponce(error: networkError.badUrl)


       // self.VCPDelegate?.successResponce(responce: [Product]())


        HTTPClient.shared.callForPostApi(urlString:"https://fakestoreapi.com/products", modelType: [Product].self, paramters:parames) { [self] isSuccuss, result in


            switch result{

            case .success(let products):

               // completion(.success(products))

                self.vcDelegate?.successResponce(responce: products)

            case.failure(let error):

               // completion(.failure(.message(error)))
                self.vcDelegate?.failureResponce(error: error)
            }


        }

    }



    func getProductsList(completion:@escaping(Result<[Product],networkError>) ->Void) {

        //let parames:[String: Encodable] = userProduct(id: 10, title: "raghu", price: 10.1)

        //let parames:[String: Encodable] = [:]

        let parames = ""



        HTTPClient.shared.callForPostApi(urlString:"https://fakestoreapi.com/products", modelType: [Product].self, paramters:parames) { isSuccuss, result in


            switch result{

            case .success(let products):

                completion(.success(products))

            case.failure(let error):

                completion(.failure(.message(error)))
            }


        }

    }
}
