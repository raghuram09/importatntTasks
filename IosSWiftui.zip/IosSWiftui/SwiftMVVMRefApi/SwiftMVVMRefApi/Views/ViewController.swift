//
//  ViewController.swift
//  SwiftMVVMRefApi
//
//  Created by Apple on 09/11/23.
//

import UIKit

protocol viewControllerDelegate {
   
   func successResponce(responce:[Product])
   func failureResponce(error: networkError?)
   
}
//extension viewControllerDelegate {
//
//    func successResponce(responce:[Product]) {
//
//
//    }
//    func failureResponce(error: networkError?) {
//
//
//    }
//
//
//
//}
class ViewController: UIViewController {

    @IBOutlet weak var productTableView: UITableView!
    var viewModel = ProductViewModel()
    var viewModelDelegate:ProductViewModelPDelegate?
    
    var productsModel:[Product]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
       // getEventData()
        
        viewModel.vcDelegate = self
        self.viewModelDelegate = viewModel
        viewModel.getProductsProtocol()
    }
    
    
    func getEventData() {
        
        viewModel.getProductsProtocol()
        
//        viewModel.getProductsProtocol { result in
//
//
//            switch result{
//
//
//            case .success(let products):
//
//               // print(products)
//                self.productsModel = products
//
//
//            case.failure(let error):
//
//                print(error)
//
//            }
//
//
//        }
        
    }
    
    
    
//    func configuration(){
//
//        initViewModel()
//        obsereEvent()
//
//    }
//    func initViewModel(){
//
//        viewModel.fetchProducts()
//    }
//    //Data Binding event
//    func obsereEvent(){
//
//        viewModel.eventHandler = { [weak self] event in
//            guard let self else{return}
//
//            switch event{
//            case .loading:
//
//                print("loading")
//            case.stopLoading:
//
//
//                print("stop loading")
//
//            case.dataLoaded:
//                DispatchQueue.main.async {
//                    print(self.viewModel.products)
//
//                    self.productTableView.reloadData()
//                }
//
//
//            case.error(let error):
//
//                print(error)
//
//
//            }
//
//        }
//    }

}

//extension ViewController:UITableViewDelegate,UITableViewDataSource{
//    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return viewModel.products.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        
//        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTVCell") as! ProductTVCell
//
//        
//       // let productData = self.articleListVM.articleAtIndex(indexPath.row)
//        let productData = self.viewModel.products[indexPath.row]
//
//        cell.productName.text = productData.title
//        cell.productDescription.text = productData.description
//        
//        cell.productImage.setimage(with: productData.image)
//        
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 150
//    }
//}


extension ViewController:viewControllerDelegate {
    func successResponce(responce: [Product]) {
        
        print("successResponce \(responce)")

    }
    
    func failureResponce(error: networkError?) {
        print("failureResponce \(error)")
        
    }
    
    
    
}
