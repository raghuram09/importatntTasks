//
//  ContentView.swift
//  TestCases
//
//  Created by Raghu on 10/03/24.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var LovinviewModel = LoginViewModel()
  
    var body: some View {
      
        ZStack{
            VStack{
                TextField("Enter your name", text: $LovinviewModel.email)
                    .textFieldStyle(.roundedBorder)
                    .textInputAutocapitalization(.never)

                TextField("Enter your password", text: $LovinviewModel.password)
                    .textFieldStyle(.roundedBorder)
                    .textInputAutocapitalization(.never)
                    .padding(.top,20)
                    

                
                
                Button(action: {
                    
                    LovinviewModel.checkValidations{ status  in
                        
                        print("..............\(status)")
                    }
                    
                }, label: {
                    Text("Login")
                })
                .frame(width: 100, height: 40)
                .background(.red)
                .tint(.white)
                .bold()
                .cornerRadius(10)
                .padding(.top,20)

            }
            .padding(20)
            
           
        }
       
    }
}

#Preview {
    ContentView()
}
