//
//  StringExtension.swift
//  TestCases
//
//  Created by Raghu on 10/03/24.
//

import Foundation

import SwiftUI

extension String{
    
    var isValidEmail: Bool {
        do {
            if self.count > 100 {
                return false
            }
            let regex = try NSRegularExpression(pattern: "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}", options: .caseInsensitive)
            return regex.firstMatch(in: self, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, self.count)) != nil
        } catch {
            return false
        }
    }
    

    var isvalidPassword:Bool{
        
        do {
            if self.count > 100 {
                return false
            }
            let regex = try NSRegularExpression(pattern: "(?=[^a-z]*[a-z])[^0-9]*[0-9].*", options: .caseInsensitive)
            return regex.firstMatch(in: self, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, self.count)) != nil
        } catch {
            return false
        }
    }

    
    func isPasswordHasNumberAndCharacter(password: String) -> Bool {
        let passRegEx = "(?=[^a-z]*[a-z])[^0-9]*[0-9].*"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", passRegEx)
        return passwordTest.evaluate(with: password)
    }
}
