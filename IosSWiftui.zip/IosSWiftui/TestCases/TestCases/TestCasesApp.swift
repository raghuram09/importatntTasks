//
//  TestCasesApp.swift
//  TestCases
//
//  Created by Raghu on 10/03/24.
//

import SwiftUI

@main
struct TestCasesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
