//
//  TestLoginValidation.swift
//  TestCasesUITests
//
//  Created by Raghu on 10/03/24.
//

import XCTest
@testable import TestCases
final class TestLoginValidation: XCTestCase {

    var LovinviewModel = LoginViewModel()

    var email:Bool = false
    func testValidEmail(){
        
        //arrage data
        
        email = true
        // act
        var expected = Bool()

        LovinviewModel.checkValidations{ status in
            
            expected == status
            
        }
        //assert
        
        XCTAssertTrue(expected, "email is valid")
        
    }

}
