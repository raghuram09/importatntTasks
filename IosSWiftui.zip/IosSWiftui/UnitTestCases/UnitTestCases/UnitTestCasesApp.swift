//
//  UnitTestCasesApp.swift
//  UnitTestCases
//
//  Created by Raghu on 26/02/24.
//

import SwiftUI

@main
struct UnitTestCasesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
