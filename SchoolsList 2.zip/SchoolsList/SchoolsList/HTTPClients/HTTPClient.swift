//
//  HTTPClient.swift
//  SchoolsList
//
//  Created by Raghu on 29/02/24.
//

import Foundation

import Combine

enum networkError:Error{
    
    case invalidUrl
    case noResponce
    case noData
}

class ApiHandler{
    
    static let shared = ApiHandler()
    
    private init(){
        
    }
    
    func getSchoolsList(completionHandler:@escaping(Result<[schoolsModel],networkError>) -> Void){
        
        guard let schoolsUrl = URL.SchoolsUrl() else{
            
            return completionHandler(.failure(.invalidUrl))
        }
        
                var request = URLRequest(url: schoolsUrl)
                request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request){ data , responce , error in
            print(".............")
            guard let data = data, error == nil else{
                
                return completionHandler(.failure(.noData))
            }
            
            do {
                let schoolsList =  try JSONDecoder().decode([schoolsModel].self,from: data)
                
                print(schoolsList)
                completionHandler(.success(schoolsList))
            }catch{
                
                completionHandler(.failure(.noResponce))
            }
        }.resume()
    }
    
}

