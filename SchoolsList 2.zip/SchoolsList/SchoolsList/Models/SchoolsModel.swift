//
//  SchoolsModel.swift
//  SchoolsList
//
//  Created by Raghu on 29/02/24.
//

import Foundation

typealias codebale = Decodable & Encodable

struct schoolsModel:codebale,Hashable{
    
    var dbn:String?
    var school_name:String?
    var school_email:String?
    
    enum CodingKeys: String, CodingKey {
       
        case dbn = "dbn"
        case school_name = "school_name"
    }
}
