import UIKit

var greeting = "Hello, playground"

class NetworkCall{
    
    static let shared = NetworkCall()
    
   private init(){
        
    }
    
}

@objc protocol getMethods{
    
    
    func A()
    
    @objc optional func B()
    
    
   
    
}

//struct C : getMethods{
//    func A() {
//
//    }
//    func B() {
//
//    }
//
//
//
//}

func getDta<T,V>(a:T,b:V) {
    
    
    print("\(a)\(b)")
    
}

 getDta(a: 10, b: "raghu")






