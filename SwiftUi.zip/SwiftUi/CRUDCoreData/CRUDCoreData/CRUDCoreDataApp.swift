//
//  CRUDCoreDataApp.swift
//  CRUDCoreData
//
//  Created by Raghu on 09/02/24.
//

import SwiftUI

@main
struct CRUDCoreDataApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, CoreDataProvider.shared.viewContext)
        }
    }
}
