//
//  ContentView.swift
//  CRUDCoreData
//
//  Created by Raghu on 09/02/24.
//

import SwiftUI

struct ContentView: View {
    @FetchRequest(fetchRequest: Movie.all)
    private var movieResult : FetchedResults<Movie>
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
