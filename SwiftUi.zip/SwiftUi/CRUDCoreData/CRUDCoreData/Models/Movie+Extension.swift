//
//  Movie+Extension.swift
//  CRUDCoreData
//
//  Created by Raghu on 09/02/24.
//

import Foundation

extension Movie:Model{
    
    
}
