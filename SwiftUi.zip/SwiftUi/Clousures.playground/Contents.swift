import UIKit

// Closure take no parameter and return nothing

let sayHello: () -> Void = {
    print("Hello")
}
sayHello()

// Closure take one parameter and return 1 parameter
let value: (Int) -> Int = { (value1) in
    return value1
}
print(value(10))

// Closure take two parameter and return 1 parameter
let add: (Int, Int) -> Int = { (value1, value2) in
    return value1 + value2
}

print(add(5, 4))

// Closure take two parameter and return String parameter
let addValues: (Int, Int) -> String = { (value1, value2)  in
    return String("Sum is: \(value1 + value2)")
}

print(addValues(5, 4))

var name12:(String) -> String = { namedata in
    
    print(namedata)
    return namedata
}

name12("raghuram")


// closure Function

var name = "raghu"

func myClosureFunction(completion:(String)-> Void){
    
    
    completion(name)
    
}
  myClosureFunction { getValue in
    print("your name is \(getValue)")
}


// capture lift using clousure

//capture list is used within closures to manage the capture of variables and constants from the surrounding context
var a = 0
var b = 0


let closure = { [a] in
    
    
    print(a,b)
    
    return a
    
}
a = 10
b = 20
closure()

// capture lift using class

//class captureValues{
//    
//    
//    var value:Int = 0
//    
//    var x = captureValues()
//    
//    var y = captureValues()
//
//    
//    let clousure = { [x] in
//        
//        print(x.value,y.value)
//    }
//    
//    x.value = 10
//    y.value = 10
//    
//    clousure()

    
//}

func getdata(data:@escaping(Result<Any,Error>)->Void){
    let str:String = "raghu"
   
    data(.success(str))
}
func getdata(url:String,completion:@escaping(Result<[AnyObject],Error>)->Void){
    
    getdata { datais in
        
        print(datais)
    }
    
}
