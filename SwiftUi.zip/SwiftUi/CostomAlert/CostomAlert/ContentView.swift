//
//  ContentView.swift
//  CostomAlert
//
//  Created by Raghu on 21/02/24.
//

import SwiftUI

struct ContentView: View {
    @State var isActive:Bool = false
    
    var body: some View {
   
        ZStack{
            VStack{
                
                Button{
                    
                    isActive = true
                    
                }label: {
               
                    Text("Show PopUp")
                }
            }
            .padding()

            if isActive {
                
                CustomDialog(isActive: $isActive, title: "MyApp", message: "Plese show The Data", buttonTitle: "Next", action: {
                    
                    print("pass to View Model")
                })
            }
            
        }
    }
}

#Preview {
    ContentView()
}
