//
//  CostomAlertApp.swift
//  CostomAlert
//
//  Created by Raghu on 21/02/24.
//

import SwiftUI

@main
struct CostomAlertApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
