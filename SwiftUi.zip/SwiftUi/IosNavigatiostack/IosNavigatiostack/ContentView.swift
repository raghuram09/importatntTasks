//
//  ContentView.swift
//  IosNavigatiostack
//
//  Created by Raghu on 28/02/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack{
            
            
        }
       
    }
}

#Preview {
    ContentView()
}
