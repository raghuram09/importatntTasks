//
//  IosNavigatiostackApp.swift
//  IosNavigatiostack
//
//  Created by Raghu on 28/02/24.
//

import SwiftUI

@main
struct IosNavigatiostackApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
