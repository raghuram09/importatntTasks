//
//  ContentView.swift
//  Navi/Users/apple/Downloads/navigation-stack-swiftui-main/NavigationStack/NavigationStackManager.swiftgationStack
//
//  Created by Apple on 15/12/23.
//

import SwiftUI

struct ContentView: View {
    
    @Binding var navPaths: [Routes]
    var body: some View {
        VStack {
            Button(action: {
                
                print("Clicked")
                navPaths.append(.sigup)

            }){
                Text("SigN Up")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 150, height: 50)
                    .background(Color.green)
                    .cornerRadius(15.0)
                    .shadow(radius: 10.0, x: 20, y: 10)
                
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(navPaths: .constant([]))
    }
}
