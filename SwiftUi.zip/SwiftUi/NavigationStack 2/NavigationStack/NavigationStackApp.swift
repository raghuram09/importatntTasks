//
//  NavigationStackApp.swift
//  NavigationStack
//
//  Created by Apple on 15/12/23.
//

import SwiftUI

@main
struct NavigationStackApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStackManager()
        }
    }
}
