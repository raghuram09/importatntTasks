//
//  NavigationStackManager.swift
//  NavigationStack
//
//  Created by Lynda Chiwetelu on 04.09.23.
//

import SwiftUI

enum Routes {
    case list
    case sigup
//    case credits
//    case quotes
}

struct NavigationStackManager: View {
    @State private var navPaths = [Routes]()
    
    var body: some View {
        NavigationStack(path: $navPaths) {
            ContentView(navPaths: $navPaths).navigationDestination(for: Routes.self) { r in
                switch(r) {
                case .list:
                    ContentView(navPaths: $navPaths)
                case .sigup:
                    
                    SignUpView(navPaths: $navPaths)
                        .navigationBarBackButtonHidden(true)

                }
            }
        }
    }
}

struct NavigationStackManager_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStackManager()
    }
}
