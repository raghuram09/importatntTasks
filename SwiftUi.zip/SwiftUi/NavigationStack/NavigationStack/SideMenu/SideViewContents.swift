//
//  SideViewContents.swift
//  SwiftUiSideNav
//
//  Created by Apple on 16/12/23.
//

import SwiftUI

enum menuFeatures:String,CaseIterable {
    case Home = "Home"
    case MyOrders = "MyOrders"
    case Settings = "Settings"
    
}
struct MenuOptions :Hashable{
    var menuName: String
    var image: String
}



struct SideViewContents: View {
    
    var menuOptions = [MenuOptions(menuName: "Home",image: "Home"),
                       MenuOptions(menuName: "MyOrders",image: "person.circle"),
                       MenuOptions(menuName: "Settings",image: "Home")]
    
    
    @Binding var presentSideMenu : Bool
    
//    @Binding var navPaths: [Routes]
    
    var body: some View {
        
        ZStack{
            
            VStack{
                
                //            SideMenuTopView()
                Spacer(minLength: 100)
                
                HStack{
                    
                    Text("raghu")
                    Text("raghu")
                }
                
                Spacer(minLength: 50)
                NavigationStack {
                    
                    
                    
                    List {
                        ForEach(Array(menuOptions.enumerated()), id: \.element) { index, item in
                                    if index == 0 {
                                        Text("raghu")
                                            .foregroundColor(.blue)
                                    } else {
                                        Text(item.menuName)
                                            .foregroundColor(.green)
                                    }
                                }
                            }
                    
                    
//                    List{
//
//                        ForEach(menuOptions, id: \.self) { index in
//
//                            HStack{
//                                Image(index.image)
//                                    .resizable()
//                                    .frame(width: 50,height: 50,alignment: .center )
//                                    .clipShape(Circle())
//                                    .overlay(Circle().stroke(Color.black,lineWidth: 2.0))
//
//                                Text(index.menuName)
//
//                            }
//
//
//                            .onTapGesture {
//
//                                if index.menuName == "Home"{
//
//                                    NavigationLink("") {
//                                        HomeView()
//                                    }
//
//
//                                }
//                            }
//
//
//                        }
//                        .listRowBackground(Color.clear)
//
//
//                    }
                }
                
                
                
                
            }
            
            
        }
        
        
    }
    
    
    
    //    @ViewBuilder
    //    private func SideMenuTopView() -> some View{
    //        ZStack{
    //            VStack(spacing: 150){
    //
    //                //            HStack{
    //                //
    //                //                Button{
    //                //                    presentSideMenu.toggle()
    //                //
    //                //                }label: {
    //                //
    //                //                    Image(systemName: "x.circle")
    //                //                        .resizable()
    //                //                        .aspectRatio(contentMode: .fit)
    //                //                        .foregroundColor(.white)
    //                //
    //                //                }
    //                //                .frame(width: 34,height: 34)
    //                ////                Spacer()
    //                //
    //                //            }
    //            }
    //        }
    //        //        .frame(maxWidth: .infinity)
    //        //        .padding([.leading, .top],40)
    //        //        .padding(.bottom,30)
    //    }
    //
    //
}

//struct SideViewContents_Previews: PreviewProvider {
//    static var previews: some View {
//        DashBoardView(navPaths: .constant([]))
//    }
//}
