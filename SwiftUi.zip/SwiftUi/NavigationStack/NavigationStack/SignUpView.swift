//
//  SignUpView.swift
//  NavigationStack
//
//  Created by Apple on 15/12/23.
//

import SwiftUI

struct SignUpView: View {
    
    @Binding var navPaths: [Routes]

    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView(navPaths: .constant([]))
    }
}
