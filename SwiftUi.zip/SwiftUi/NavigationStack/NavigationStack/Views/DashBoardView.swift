//
//  DashBoard.swift
//  SwiftUiSideNav
//
//  Created by Apple on 16/12/23.
//

import SwiftUI

struct DashBoardView: View {
    
    @State var presentSideMenu = false

    var body: some View {
       
        ZStack{
            
            Color.white.edgesIgnoringSafeArea(.all)
            
            VStack{
                
                
            }
            .frame(maxWidth: .infinity,maxHeight: .infinity)
            
            .overlay(alignment: .top) {
                ZStack{
                    
                    HStack{
                        
                        Button{
                            
                            presentSideMenu.toggle()
                            
                        } label: {
                            
                            Image("Menu")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                        .frame(width: 24,height: 24)
                        .padding(.leading,30)
                        Spacer()
                        
                    }
                }
                .frame(maxWidth: .infinity)
                .frame(maxHeight: 56)
                .background(Color.white)
//                zIndex(1)
//                    .shadow(radius: 0.5 )
                
            }
            .background(Color.gray.opacity(0.8))
            SideMenu()
        }
        .frame(maxWidth: .infinity)
    }
    
    @ViewBuilder
    private func SideMenu() -> some View{
        
        SideMenuView(isShowing: $presentSideMenu, direction: .leading){
            
            SideViewContents(presentSideMenu: $presentSideMenu)
                .frame(width: 300)
        }
    }
}

struct DashBoard_Previews: PreviewProvider {
    static var previews: some View {
        DashBoardView()
    }
}
