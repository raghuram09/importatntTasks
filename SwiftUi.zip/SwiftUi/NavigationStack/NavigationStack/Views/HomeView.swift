//
//  HomeView.swift
//  SwiftUiSideNav
//
//  Created by Apple on 07/01/24.
//

import SwiftUI

struct HomeView: View {
    
    let items = ["Apple", "Banana", "Orange", "Grapes"]

    var body: some View {
      
        List {
                    ForEach(Array(items.enumerated()), id: \.element) { index, item in
                        if index == 0 {
                            Text("raghu")
                                .foregroundColor(.blue)
                        } else {
                            Text(item)
                                .foregroundColor(.green)
                        }
                    }
                }
        
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
