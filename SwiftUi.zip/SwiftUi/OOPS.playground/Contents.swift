import UIKit

//inheritance
//protocol ParentClass{
//    func getparentSkills()
//
//}
//
//extension ParentClass{
//
//    func getparentSkills(){
//
//        print("parent skills from protocol")
//
//    }
//}
//class parent2child{
//
//    func getChildSkills(){
//
//        print("child skills")
//    }
//}
//
//class Employee{
//
//    var name: String!
//    var age:Int!
//
//
//    func getName(name:String,age:Int){
//
//        print(name,age)
//
//    }
//
//
//}
//
//
//
//class developer:Employee{
//
//    var role:String!
//    var salary :Int!
//
//    func getage(age:Int){
//
//        print(age)
//
//    }
//
//
//
//}
//
//class manager:parent2child,ParentClass{
//
//    var designation:String!
//    func getparentSkills() {
//
//
//    }
//
//}
    
//    let developerinfo = developer()
//
//developerinfo.getName(name: "sandhya", age: 29)
//
//

//Polimorphisum

// Polimorphisum IS one form to multipleform

//method overloading  two or more methods haveing same name  but diffarent implementation of parameters like type of parameter ,order of parameter ,number of parameter

//methodoverloading
//class calculator{
//
//
//    func addSum(i:Int,j:Int)->Int{
//
//        return i+j
//
//    }
//
//    func addSum(i:Double,j:Double)->Double{
//
//
//        return i+j
//    }
//}
//let cal = calculator()
//
//cal.addSum(i: 10.0, j: 20.23123)
//cal.addSum(i: 10, j: 20)


//MethodoverRiding

//class parentClass{
//
//    var parentAmmount:Int{
//
//        return 500
//    }
//
//    var totalAmmount:Int{
//
//        return parentAmmount
//    }
//}
//
//class ChildClass:parentClass{
//
//    var childAmmount:Int{
//
//        return 300
//    }
//
//    override  var totalAmmount: Int{
//
//        return super.totalAmmount + childAmmount
//    }
//}
//
//
//let child = ChildClass()
//
//child.totalAmmount


//class raghu{
//
//
//    func name() ->String{
//
//        return "raghu"
//    }
//
//}
//
//
//class rajini:raghu{
//
//    override func name() -> String {
//        return "rajini"
//    }
//
//}
//
//
//class pavan:raghu{
//
//    override func name() -> String {
//
//        return "pavan"
//    }
//}
//
//let Raghu = raghu()
//
//let raghuName = Raghu.name()
//let rajiniInfo = rajini()
//
//let rajiniName = rajiniInfo.name()
//
//let panan = pavan()
//
//let name = panan.name()



    // STRORED AND COMPUTED PROPERTY



//struct loanCalculator{
//
//    var loanAmmount:Int
//
//    let rateofInterest = 10
//
//    var year:Int
//
//    var simpleInterest:Int
//
//    {
//        get{
//
//            return (loanAmmount * rateofInterest * year) / 100
//        }
//
//    }
//
//}

//let loanCalculatorprice = loanCalculator(loanAmmount: 500000, year: 5)
//
//print(loanCalculatorprice)
//debugPrint("interest ammount = \(loanCalculatorprice.simpleInterest)")

//

//area calculator

//struct Circle{
//
//    var radius: Double = 0
//
//    var area:Double
//
//    {
//        get{
//
//            return radius * radius * Double.pi
//
//        }
//
//        set(areaVal){
//
//            radius = sqrt(areaVal/Double.pi)
//        }
//
//    }
//
//}
//
//
//var circle = Circle()
//
//circle.radius = 5
//
//debugPrint("area = \(circle.area)")
//
//circle.radius = 25
//
//debugPrint("radius = \(circle.radius)")
//
//circle.radius = 100
//
//debugPrint("radius = \(circle.radius)")



//logics



let a = 10
let b = "10"
let c = false
let arry = [1,2,3]
let array = ["apple", "dog", "log"]
let str = "raghuram"
var dict = ["name": "raghu","age": "29","role":"developer"]
debugPrint(dict.updateValue("city", forKey: "hyderabad") ?? "")

//for i in str where i == "a"{
//
//    debugPrint(i)
//}


    // even and odd numbers

//for i  in 0...100{
//
//
//    if (i % 2 == 0){
//
//       // debugPrint(i)
//    }
//}
//

//let number = 7
//var isItPrime: Bool = true
//for i in 2 ..< number {
//    if number % i == 0 {
//        isItPrime = false
//    }
//}
//print(isItPrime)



func printNumbers(n: Int){
    for i in 1...n {
        var count = 0
        for j in 1..<i {
            if i % j == 0 {
                count += 1
            }
        }
        if count <= 1 {
            print(i, "is prime")
        }
        
    }
}

printNumbers(n: 100)
