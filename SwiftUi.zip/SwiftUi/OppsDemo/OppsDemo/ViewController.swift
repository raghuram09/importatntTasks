//
//  ViewController.swift
//  OppsDemo
//
//  Created by Apple on 04/11/23.
//

import UIKit

enum Weekday:String {
    case Monday = "Monday"
    case Tuesday = "Tuesday"
    case Wednesday = "Wednesday"
    case Thursday = "Thursday"
    case Friday = "Friday"
    case Saturday = "Saturday"
    case Sunday = "Sunday"
    
}




enum Operator: String {
    case addition = "+"
    case subtraction = "-"
    case multiplication = "*"
    case division = "/"
}

enum PizzaSize {
    case small, medium, large
}

class ViewController: UIViewController {
    
    var name :String!
    
    var array = [String]()
    
    var revArray = [String]()
    
    
    var Comparray = ["IBM","Cognizant"]
    
    var companiesDict = [String: String]()
    
    var Weekday: Weekday = .Thursday
    
    var size = PizzaSize.medium
    
    var numk=[1,2,3,7,8,9,33,99,56,59,11]
    
    let fg = ["A","B","I","D","O"];

    var VovelValue = ["A","E","I","O","U"]
    
    var finalValue = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        
        var numbers = [4,16,25,36,60]
        
        for i in numbers{
            
            let y = sqrt(Double(i))
            
            print(y)
        }
        
//        var arr = [Int]()
//        var dup=[1,2,3,4,4,4,1,5,4,6,7,6]
//        for i in dup{
//            if !arr.contains(i){
//                arr.append(i)
//            }
//        }
//        print(arr)
//
//        for i in VovelValue {
//            for j in fg {
//
//                if i == j
//                {
//                    finalValue.append(i)
//                }else{
//                }
//            }
//        }
//        print("\(finalValue)")

        
        switch(size) {
        case .small:
            print("I ordered a small size pizza.")
            
            
        case .medium:
            print("I ordered a medium size pizza.")
            
        case .large:
            print("I ordered a large size pizza.");
            
        }
        
        
        companiesDict = ["AAPL" : "Apple Inc", "GOOG" : "Google Inc", "AMZN" : "Amazon.com, Inc", "FB" : "Facebook Inc"]
        
        companiesDict.updateValue("ANTS LLC", forKey: "ants")
        
        
        for (key, name )in companiesDict {
            
            print("\(key) is \(name)")
            
            array.append(name)
            //let bookName = accounts[indexPath.row]["bookName"] as! String
        }
        
        
        
        array.append("Iconma")
        array.append(contentsOf: Comparray)
        
        print(array)
        
        for index in array.reversed() {
            
            print("\(index)..")
            
            
            revArray.append(index)
            
        }
        
        print(revArray)
        
        let filteredArray = array.filter { $0.contains("A") }
        
        
        print(filteredArray)
        
    }
    
}
