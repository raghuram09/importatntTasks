//
//  ContentView.swift
//  SideMenuSwiftUI
//
//  Created by Apple on 02/01/24.
//

import SwiftUI

struct DashBoard: View {
    
    @State var menuOption = false
    var body: some View {
        ZStack{
            
            if !menuOption{
                
                Button(action: {
                    
                    self.menuOption.toggle()
                    
                }, label: {
                    
                    Text("Menu")
                        .bold()
                        .foregroundColor(Color.white)
                        .frame(width: 200,height: 50,alignment: .center)
                        .background(Color(.blue))
                        .cornerRadius(10)
                })
                
            }
            
            SideMenuView(width: UIScreen.main.bounds.width/2, menuOption: menuOption, toggleMenu: toggleMenu)
            
        }
        .edgesIgnoringSafeArea(.all)
    }
    
    func toggleMenu() {
        menuOption.toggle()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        DashBoard()
    }
}
