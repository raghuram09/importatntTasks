//
//  SideMenuView.swift
//  SideMenuSwiftUI
//
//  Created by Apple on 02/01/24.
//

import SwiftUI

struct MenuItem:Identifiable{
    
    var id = UUID()
    var name:String?
}

struct menuContent:View{
    
    let items:[MenuItem] = [
    
        MenuItem(name: "Home"),
        MenuItem(name: "Products"),
        MenuItem(name: "Myorders"),
        MenuItem(name: "News"),
        MenuItem(name: "Settings"),
        MenuItem(name: "Users"),

    ]
    var body: some View{
        
        ZStack{
            
            ZStack{
                
//              Color(uiColor:(red: 33/255.0, green: 33/255.0, blue: 33/255.0 , alpha:1))
                
                VStack(alignment: .leading, spacing: 0){
                    ForEach( items ) { item in
                        
                        
                    }
                    Spacer()
                    
                }

            }
        }
    }
}

struct SideMenuView: View {
    
    let width: CGFloat
    let menuOption: Bool
    let toggleMenu: () -> Void
    var body: some View {
        ZStack{
            //backgroundView
            GeometryReader{ _ in
                
                EmptyView()
            }
            .background(Color.red)
            .opacity(self.menuOption ? 1 : 0)
            .animation(Animation.easeIn.delay(0.25))
            .onTapGesture {
                
                self.toggleMenu()
            }
            //menuContent
            Spacer()

            HStack{
                menuContent()
                    .frame(width: width)
                    .offset(x:menuOption ? 0 : -width)
                    .animation(.default)
                

                
            }
            Spacer()

            
            
        }

    }
}

//struct SideMenuView_Previews: PreviewProvider {
//    static var previews: some View {
//        SideMenuView(width: 370, menuOption: true, toggleMenu: )
//    }
//}
