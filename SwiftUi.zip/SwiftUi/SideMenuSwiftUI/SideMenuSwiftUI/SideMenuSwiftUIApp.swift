//
//  SideMenuSwiftUIApp.swift
//  SideMenuSwiftUI
//
//  Created by Apple on 02/01/24.
//

import SwiftUI

@main
struct SideMenuSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            DashBoard()
        }
    }
}
