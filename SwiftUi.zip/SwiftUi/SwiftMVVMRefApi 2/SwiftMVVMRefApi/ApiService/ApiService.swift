//
//  ApiService.swift
//  SwiftMVVMRefApi
//
//  Created by Apple on 09/11/23.
//

import Foundation

enum networkError:Error{
    
    case badUrl
    case decodingError
    case noData
    case message(_ error:Error)
}

class ApiService{
    
    static let shared = ApiService()
    
   private init(){
        
    }
    func getProductsData(completionHandler: @escaping(Result<[Product],networkError>)->Void){
        
        
        guard let productUrl = URL.productURL() else{
            
            return completionHandler(.failure(.badUrl))
        }
        
        
//        var request = URLRequest(url: productUrl)
//        request.httpMethod == "POST"
//        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
       // request.httpBody = try? JSONEncoder().encode(createAccountRequest)

        
        URLSession.shared.dataTask(with: productUrl) { data, responce, error in
            
            guard let data = data, error == nil else {
                return completionHandler(.failure(.noData))
            }
            
            do {
                
                let products = try JSONDecoder().decode([Product].self, from: data)
                
                completionHandler(.success(products))
                
                
            } catch{
                
                completionHandler(.failure(.message(error)))
            }
            
            
        }.resume()
        
    }
    
    
}
