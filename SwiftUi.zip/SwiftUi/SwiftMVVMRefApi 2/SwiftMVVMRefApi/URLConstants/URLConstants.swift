//
//  URLConstants.swift
//  SwiftMVVMRefApi
//
//  Created by Apple on 09/11/23.
//

import Foundation

extension URL{
    
    static func productURL() ->URL?{

        return URL(string: "https://fakestoreapi.com/products")
        
    }
    
}

