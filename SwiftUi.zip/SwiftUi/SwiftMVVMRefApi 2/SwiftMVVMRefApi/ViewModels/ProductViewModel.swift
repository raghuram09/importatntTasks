//
//  ProductViewModel.swift
//  SwiftMVVMRefApi
//
//  Created by Apple on 09/11/23.
//

import Foundation

class ProductViewModel{
    
    var products:[Product] = []
    
    var eventHandler: ((_ event:Event) ->Void)?  // data binding closure
    func fetchProducts(){
        
        self.eventHandler?(.loading)
        ApiService.shared.getProductsData { responce in
            
            self.eventHandler?(.stopLoading)

            switch responce{
                
                
            case .success(let products):
                
               // print(products)
                self.products = products
                
                self.eventHandler?(.dataLoaded)
                
            case.failure(let error):
                
                print(error)
                self.eventHandler?(.error(error))
            }
            
        }
    }
}
extension ProductViewModel{
    
    enum Event{
        
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
    }
}
