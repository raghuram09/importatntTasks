//
//  VCPresenter.swift
//  SwiftMVVMRefApi
//
//  Created by Apple on 19/11/23.
//

import Foundation


protocol VCPresenterDelegate {
    
    //func presenterMethodHitted()
    func presentSuccessResponce(responce:[Product])
    func presentFailureResponce(error: networkError?)
    
}

class VCPresneter:VCPresenterDelegate {
    
    var vcDelegate:viewControllerDelegate?
    
    func presentSuccessResponce(responce: [Product]) {
        
        vcDelegate?.successResponce(responce: responce)
    }
    
    func presentFailureResponce(error: networkError?) {
        
        vcDelegate?.failureResponce(error: error)
    }
    
    
  

    
    
    
}
