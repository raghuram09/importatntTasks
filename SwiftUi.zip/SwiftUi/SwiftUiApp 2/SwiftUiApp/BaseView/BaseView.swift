//
//  BaseView.swift
//  SwiftUiApp
//
//  Created by Apple on 27/12/23.
//

import SwiftUI

struct BaseView: View {
    
    @Binding var presentSideMenu: Bool
    @State  var menuTitle: String = ""



    var body: some View {

        HStack{
            MenuBtn
            
            Spacer()
            
            VStack(spacing: 4){
                
                Text(menuTitle)
                    .frame(alignment: .center)
            }
            Spacer()
                .opacity(0)
        }
        .padding()
        .font(.headline)
        .background(Color.blue.ignoresSafeArea(edges:.top))
      }
}

//struct BaseView_Previews: PreviewProvider {
//    static var previews: some View {
//        VStack{
//            BaseView(presentSideMenu: )
//            Spacer()
//        }
//    }
//}


extension BaseView{
    
    private var MenuBtn: some View{
        
        Button(action: {
            
            presentSideMenu.toggle()

        }, label: {
            Image("menu")
                .resizable()
                .frame(width: 30, height: 30)
                .cornerRadius(8)

        })
        
    }
}
