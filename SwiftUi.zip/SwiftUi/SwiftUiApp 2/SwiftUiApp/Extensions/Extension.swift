//
//  Extension.swift
//  SwiftUiApp
//
//  Created by Apple on 01/01/24.
//

import Foundation

extension URL{
    
    static func productURL() ->URL?{

        return URL(string: "https://www.industrybuying.com/api/v1/catalogs/categories/")
        
    }
    
}
