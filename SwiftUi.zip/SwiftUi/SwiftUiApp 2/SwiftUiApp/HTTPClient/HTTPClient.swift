//
//  HTTPClient.swift
//  SwiftUiApp
//
//  Created by Apple on 01/01/24.
//

import Foundation

enum networkError:Error{
    
    case badUrl
    case decodingError
    case noData
    case message(_ error:Error)
}

class HTTPClient {
    
    static let shared = HTTPClient()
    
    private init(){
        
    }
    
    var extraHeaders:KeyValuePairs <String,String>? = nil

    func getRequest(url: URL, timeOutInterval: TimeInterval = 30) -> NSMutableURLRequest {
        let theRequest = NSMutableURLRequest(url: url,
                                             cachePolicy: .reloadIgnoringLocalCacheData,
                                             timeoutInterval: timeOutInterval)
        
        theRequest.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        theRequest.addValue("MTYIOS", forHTTPHeaderField: "User-Agent")//useragent type
        
        theRequest.httpMethod = "GET"
        //theRequest.httpBody = parms
        return addExtraHeadersIfNeeded(request: theRequest)
    }
    
    func addExtraHeadersIfNeeded(request: NSMutableURLRequest) -> NSMutableURLRequest {
        guard let moreHeaders = extraHeaders else {
            return request
        }
        for header in moreHeaders {
            request.addValue(header.value, forHTTPHeaderField: header.key)
        }
        return request
    }
    
    func callForGetApi<T:Codable>(urlString: String, modelType: T.Type, paramters: String, complesion:@escaping(Bool,Result<T, networkError>) -> Void) {
        
        guard let productUrl = URL.productURL() else{
            
            return complesion(false,.failure(.badUrl))
        }
        
        
        URLSession.shared.dataTask(with: getRequest(url: productUrl) as URLRequest) { data, responce, error in
            
            guard let data = data, error == nil else {
                return complesion(false,.failure(.noData))
            }
            //responcestatuscode check
            
            let statusCode = (responce as? HTTPURLResponse)?.statusCode
            
            if let statusCode1 = statusCode, 200...299 ~= statusCode1{
                
                //
                
            }
            
            do {
                let model = try JSONDecoder().decode(T.self, from: data)

                complesion(true,.success(model))
            }catch{
                
                 complesion(false,.failure(.message(error)))
            }
            
        }.resume()
        
    }
}
