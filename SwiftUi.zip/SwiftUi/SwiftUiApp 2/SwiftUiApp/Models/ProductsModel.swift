//
//  ProductsModel.swift
//  SwiftUiApp
//
//  Created by Apple on 01/01/24.
//

import Foundation

// MARK: - Welcome
struct Categories: Codable {
    let status: String?
    let data: [CategoriesData]?
    let userData: UserData?
    let userTypeValidation: String?

    enum CodingKeys: String, CodingKey {
        case status, data
        case userData = "user_data"
        case userTypeValidation = "user_type_validation"
    }
}

// MARK: - Datum
struct CategoriesData: Codable {
    let name: String?
    let id: Int?
    let images: Images?
    let icon: String?
    let childCats: [DatumChildCat]

    enum CodingKeys: String, CodingKey {
        case name, id, images, icon
        case childCats = "child_cats"
    }
}

// MARK: - DatumChildCat
struct DatumChildCat: Codable {
    let name: String
    let id: Int
    let images: Images?
    let childCats: [ChildCatChildCat]

    enum CodingKeys: String, CodingKey {
        case name, id, images
        case childCats = "child_cats"
    }
}

// MARK: - ChildCatChildCat
struct ChildCatChildCat: Codable {
    let name: String
    let id: Int
    let images: Images?
    let childCats: [ChildCatChildCat]
    let icon: String?

    enum CodingKeys: String, CodingKey {
        case name, id, images
        case childCats = "child_cats"
        case icon
    }
}

// MARK: - Images
struct Images: Codable {
    let small, mini, micro, path: String
    let original: String
    let alt, title: String?
}

// MARK: - UserData
struct UserData: Codable {
    let cartCount: String

    enum CodingKeys: String, CodingKey {
        case cartCount = "cart_count"
    }
}
