//
//  NavigationStackManager.swift
//  SwiftUiApp
//
//  Created by Apple on 27/12/23.
//

import SwiftUI

enum Routes {
    case login
    case Menu
//    case Home
//    case dashBoard
//    case quotes
}

struct NavigationStackManager: View {
    @State private var navPaths = [Routes]()
    @State var menuTitle : String = ""

    
    
    var body: some View {
        NavigationStack(path: $navPaths) {
            ContentView(navPaths: $navPaths).navigationDestination(for: Routes.self) { r in
                switch(r) {
                case .login:
                    ContentView(navPaths: $navPaths)
                    
                    
                case .Menu:
                    
                    MenuTapView(navPaths: $navPaths, menuTitle:"").navigationBarBackButtonHidden(true)
                    
                    
                }
            }
        }
    }
}

//struct NavigationStackManager_Previews: PreviewProvider {
//    static var previews: some View {
//        NavigationStackManager()
//    }
//}
