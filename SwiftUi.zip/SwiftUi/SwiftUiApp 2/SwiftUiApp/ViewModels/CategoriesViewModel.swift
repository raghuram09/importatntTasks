//
//  CategoriesViewModel.swift
//  SwiftUiApp
//
//  Created by Apple on 01/01/24.
//

import Foundation

class CategoriesViewModel :ObservableObject{
    
    @Published var categoriesList: Categories?
    
    func GetCategoriesList(){
        
        let params = ""
        
        HTTPClient.shared.callForGetApi(urlString: "https://www.industrybuying.com/api/v1/catalogs/categories/", modelType: Categories.self, paramters: params) { isSuccuss, result in
            
            switch result{

            case.success(let products):
                DispatchQueue.main.async {
                    
                    self.categoriesList = products

                }
                

            case.failure(let error):

                print(error)

            }
                
        }
        
    }
    
}
