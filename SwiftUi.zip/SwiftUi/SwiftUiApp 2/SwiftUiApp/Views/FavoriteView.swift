//
//  FavoriteView.swift
//  SwiftUiApp
//
//  Created by Apple on 27/12/23.
//

import SwiftUI

struct FavoriteView: View {
    @Binding var presentSideMenu: Bool
    @Binding var menuTitle : String


    var body: some View {
        VStack{
            BaseView(presentSideMenu: $presentSideMenu,menuTitle: "favorite")
            Spacer()

        }
        
    }
}


