//
//  HomeView.swift
//  SwiftUiApp
//
//  Created by Apple on 27/12/23.
//

import SwiftUI
import Kingfisher

struct HomeView: View {
    @Binding var presentSideMenu: Bool
    @Binding var menuTitle : String
    @ObservedObject var viewModel = CategoriesViewModel()
    
    var body: some View {
        
        
        VStack{
            BaseView(presentSideMenu: $presentSideMenu,menuTitle: "Home")
            Spacer()
            
            List(viewModel.categoriesList?.data ?? [],id: \.id){ dataList in
                
                HStack{
                    
                    KFImage(URL(string: dataList.icon ?? "https://static3.industrybuying.com/navigation/1501837570agriculture-garden-landscaping.png"))
                        .resizable()
                        .aspectRatio( contentMode: .fit)
                        .clipShape(Circle())
                        .frame(width: 80,height: 80,alignment: .leading)
            
                    
                    VStack{
                    
                        Text(dataList.name ?? "")

                        
                    }

                }
            
                
                
            }
            
        }
        .onAppear{
            
            viewModel.GetCategoriesList()
            
        }
        
    }
}

