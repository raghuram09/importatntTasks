//
//  MenuTapView.swift
//  SwiftUiApp
//
//  Created by Apple on 27/12/23.
//

import SwiftUI

struct MenuTapView: View {
    
    @State var presentSideMenu = false
    @State var selectedSideMenuTab = 0
    @Binding var navPaths: [Routes]
    @State var menuTitle : String

    var body: some View {
      
        ZStack{
            
            TabView(selection: $selectedSideMenuTab) {
                HomeView(presentSideMenu: $presentSideMenu, menuTitle: $menuTitle)
                    .tag(0)
                FavoriteView(presentSideMenu: $presentSideMenu,menuTitle: $menuTitle)
                    .tag(1)
                Settings(presentSideMenu: $presentSideMenu, menuTitle:$menuTitle)
                    .tag(2)
                Profile(presentSideMenu: $presentSideMenu,menuTitle: $menuTitle)
                    .tag(3)
                MyOrders(presentSideMenu: $presentSideMenu,menuTitle: $menuTitle)
                    .tag(4)
                
            }
            
            SideMenu(isShowing: $presentSideMenu, content: AnyView(SideMenuView(selectedSideMenuTab: $selectedSideMenuTab, presentSideMenu: $presentSideMenu)))
        }
    }
}

//struct MenuTapView_Previews: PreviewProvider {
//    static var previews: some View {
//        MenuTapView(navPaths: .constant([]), menuTitle: "Home")
//    }
//}
