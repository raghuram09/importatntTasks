//
//  MyOrders.swift
//  SwiftUiApp
//
//  Created by Apple on 01/01/24.
//

import SwiftUI

struct MyOrders: View {
    
    @Binding var presentSideMenu: Bool
    @Binding var menuTitle : String
    
    var body: some View {
       
        VStack{
            BaseView(presentSideMenu: $presentSideMenu, menuTitle: "MyOrders")
            Spacer()

        }
    }
}

//struct MyOrders_Previews: PreviewProvider {
//    static var previews: some View {
//        MyOrders(presentSideMenu: $presentSideMenu, menuTitle: "Myorders")
//    }
//}
