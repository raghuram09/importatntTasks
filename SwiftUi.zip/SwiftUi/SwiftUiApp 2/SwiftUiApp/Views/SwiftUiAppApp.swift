//
//  SwiftUiAppApp.swift
//  SwiftUiApp
//
//  Created by Apple on 27/12/23.
//

import SwiftUI

@main
struct SwiftUiAppApp: App {

    var body: some Scene {
        WindowGroup {
            NavigationStackManager()
        }
    }
}
