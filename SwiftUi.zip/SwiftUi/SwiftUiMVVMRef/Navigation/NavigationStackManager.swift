//
//  NavigationStackManager.swift
//  SwiftUiMVVMRef
//
//  Created by Apple on 15/12/23.
//

import SwiftUI

enum Routes{
    
    case login
    case register
    //case dashboard
}

struct NavigationStackManager: View {
    
    @State private var navPaths = [Routes]()
    
    var body: some View {
        NavigationStack(path: $navPaths) {
            LoginView(navPaths: $navPaths).navigationDestination(for: Routes.self) { r in
                
                switch(r) {
                    
                case .login:
                    
                    LoginView(navPaths: $navPaths )
                    
                case .register:
                    
                    RegisterView()
               
                }
                
            }
        }
    }
}

struct NavigationStackManager_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStackManager()
    }
}
