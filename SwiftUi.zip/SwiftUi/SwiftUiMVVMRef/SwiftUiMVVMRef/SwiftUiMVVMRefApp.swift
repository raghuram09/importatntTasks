//
//  SwiftUiMVVMRefApp.swift
//  SwiftUiMVVMRef
//
//  Created by Apple on 14/11/23.
//

import SwiftUI

@main
struct SwiftUiMVVMRefApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStackManager()
           
            }
        }
    }

