//
//  ContentView.swift
//  SwiftUiMVVMRef
//
//  Created by Apple on 14/11/23.
//

import SwiftUI

struct Movie:Hashable{
    let name:String
    
}

struct LoginView: View {
    
    @State private var email = "r@gmail.com"
    @State private var password = "Reddy@123$"
    
    @State private var dashBoardViewnav = false
    
    @State private var isShowingRegisterView = false

    @Binding var navPaths:[Routes]
 
    var body: some View {
        
     
            ZStack{
                ScrollView{
                    NavigationStack{
                    
                    VStack {
                        Text("IOS App Template")
                            .font(.largeTitle).foregroundColor(Color.white)
                            .padding([.top, .bottom], 10)
                            .shadow(radius: 10.0,x: 20,y: 10)
                        
                        Image("iosapptemplate")
                            .resizable()
                            .frame(width:250,height: 250)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.white, lineWidth: 4))
                            .shadow(radius: 10.0, x: 20, y: 10)
                            .padding(.bottom, 50)
                        
                        VStack(alignment: .leading, spacing: 50){
                            
                            TextField("Email",text: self.$email)
                                .padding()
                                .background(Color.themeTextField)
                                .cornerRadius(20.0)
                                .shadow(radius: 10.0, x: 20, y: 10)
                            TextField("Password",text: self.$password)
                                .padding()
                                .background(Color.themeTextField)
                                .cornerRadius(20.0)
                                .shadow(radius: 10.0, x: 20, y: 10)
                            
                            
                        }.padding([.leading, .trailing], 27.5)
                        
                        Button(action: {
                            
                            
                            if email.isValidEmail && password.count > 5 && password.count <= 15 && password.isvalidPassword{
                                
                                navPaths.append(.register)
                                
                            }else{
                                
                                print("invalid ")
                            }
                            
                            
                        }){
                            
                            Text("login")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding()
                                .frame(width: 300, height: 50)
                                .background(Color.green)
                                .cornerRadius(15.0)
                                .shadow(radius: 10.0, x: 20, y: 10)
                            
                        }
                        .padding(.top, 50)
                        Spacer()
                        HStack{
                            Button(action: {
                                print("Clicked")
                            

                            }){
                                
                                Text("Register")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .frame(width: 150, height: 50)
                                    .background(Color.green)
                                    .cornerRadius(15.0)
                                    .shadow(radius: 10.0, x: 20, y: 10)
                                
                            }
                            
                          
                            //.navigationDestination(isPresented: $isShowingRegisterView, destination: { RegisterView()})

                            
                            Button(action: {
                                
                                print("Clicked")
                                
                            }){
                                Text("SigN Up")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .frame(width: 150, height: 50)
                                    .background(Color.green)
                                    .cornerRadius(15.0)
                                    .shadow(radius: 10.0, x: 20, y: 10)
                                
                            }
                            
                        }
                        .padding(.top, 30)
                    }
                }
            }.background(
                LinearGradient(gradient: Gradient(colors: [.purple, .blue]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all))
        }
        
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
      //  NavigationStack{
        LoginView(navPaths: .constant([]))
    }
}
