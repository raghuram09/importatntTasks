//
//  RegisterView.swift
//  SwiftUiMVVMRef
//
//  Created by Apple on 14/11/23.
//

import SwiftUI

struct RegisterView: View {
    
    var body: some View {
        
        ZStack{
            ScrollView{
                NavigationStack{
                    VStack{
                        
                        Text("Registration")
                            .font(.headline)
                            .tint(Color.red)
                            .padding([.top,.bottom],10)
                        
                    }
                }.navigationBarBackButtonHidden()
            }
        }
    }
}

struct RegisterView_Previews: PreviewProvider {
    static var previews: some View {
        RegisterView()
    }
}
