//
//  ContentView.swift
//  XcTestDemo
//
//  Created by Raghu on 02/05/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var enterAmount:String = ""
    @State private var tipAmount:Double = 0
    @State private var totalAmount:Double = 0
    @State private var tipSlider:Double = 0



    
    var body: some View {
        VStack(spacing:40) {
            VStack{
                
                Text("Enter Bill Amount")
                    .foregroundColor(.secondary)
                
                TextField("0.00",text: $enterAmount)
                    .font(.system(size: 70,weight: .semibold,design: .rounded))
                    .keyboardType(.decimalPad)
                    .border(.black, width: 0.5)
                    .cornerRadius(5)

            }
            Text("Tip:\(tipSlider,specifier: "%.0f")%")
            Slider(value: $tipSlider,in: 0...100,step: 1)
                .onChange(of: tipSlider){ _ in
                    
                    guard let amount = Double(enterAmount) else{
                        
                        print("invaliEntry")
                        return
                    }
                    guard let tip = Calculation().calculateTip(of: amount, with: tipSlider) else {
                        print("bill amount or tip can not be negative")

                        return
                    }
                    print(tip)
                    tipAmount = tip
                    totalAmount = amount + tipAmount
                    
                    
                }
            VStack{
                Text(tipAmount,format: .currency(code: "USD"))
                    .font(.title.bold())
                Text("Tip")
                    .foregroundColor(.secondary)
                    .font(.caption)
            }
            .padding(.top,20)
            
            VStack{
                Text(totalAmount,format: .currency(code: "USD"))
                    .font(.title.bold())
                Text("Total")
                    .foregroundColor(.secondary)
                    .font(.caption)
            }
            .padding(.top,20)
           
        }
        .padding(30)
    }
}

#Preview {
    ContentView()
}

struct Calculation{
    
    func calculateTip(of enteredAmount:Double , with tip:Double) -> Double?{
        
        guard  enteredAmount >= 0 && tip >= 0 else{return nil}
        let tipPercentage = tip / 100
        
        return enteredAmount * tipPercentage
    }
}
