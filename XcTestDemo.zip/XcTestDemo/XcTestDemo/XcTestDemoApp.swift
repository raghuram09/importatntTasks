//
//  XcTestDemoApp.swift
//  XcTestDemo
//
//  Created by Raghu on 02/05/24.
//

import SwiftUI

@main
struct XcTestDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
