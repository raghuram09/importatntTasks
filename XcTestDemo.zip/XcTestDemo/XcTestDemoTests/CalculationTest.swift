//
//  CalculationTest.swift
//  XcTestDemoTests
//
//  Created by Raghu on 02/05/24.
//

import XCTest
@testable import XcTestDemo

final class CalculationTest: XCTestCase {

    func testSuccessfulTipCalculation(){
        
        //Given
        let enteredAmount = 100.00
        let tipSlider = 25.0
        let calculation = Calculation()
        
        // when(Act)
        
        let tip = calculation.calculateTip(of: enteredAmount, with: tipSlider)
        
        print("test data is \(tip ?? 0)")
        XCTAssertEqual(tip, 25)
    }

}
